package Bangpractice;

public class Playerclass {
	
	
	int p1,p2,p3,p4;
	String p1class;		
	String p2class;
	String p3class;
	String p4class;
	
	String error;
	
	public  Playerclass() {
		
			p1 =  (int)(Math.random()*4);
			
			
			do {
				p2 = (int)(Math.random()*4);
				
			} while(p1 == p2);
			
			
			do {
				p3 = (int)(Math.random()*4);
				
			} while(p3 == p1 || p3 == p2);
			
			
			do {
				p4 = (int)(Math.random()*4);
				
			} while(p4 == p1 || p4 == p2 || p4==p3);
			
			
			
	}
	
	public int Player1class() {
		
		
		if(p1==0) {
			p1class = "보안관";
			return 0;
		}
		else if(p1==1) {
			p1class = "부관";
			return 1;
		}
		else if(p1==2) {
			p1class = "무법자";
			return 2;
		}
		else if(p1==3) {
			p1class = "배신자";
			return 3;
		}
		else {
			error = "잘못된 값이 들어왔습니다.";
			return 100;
		}
		
	}
	
public int Player2class() {
		
		
	if(p2==0) {
		p2class = "보안관";
		return 0;
	}
	else if(p2==1) {
		p2class = "부관";
		return 1;
	}
	else if(p2==2) {
		p2class = "무법자";
		return 2;
	}
	else if(p2==3) {
		p2class = "배신자";
		return 3;
	}
	else {
		error = "잘못된 값이 들어왔습니다.";
		return 100;
	}
		
	}

public int Player3class() {
	
	
	if(p3==0) {
		p3class = "보안관";
		return 0;
	}
	else if(p3==1) {
		p3class = "부관";
		return 1;
	}
	else if(p3==2) {
		p3class = "무법자";
		return 2;
	}
	else if(p3==3) {
		p3class = "배신자";
		return 3;
	}
	else {
		error = "잘못된 값이 들어왔습니다.";
		return 100;
	}
	
}

public int Player4class() {
	
	
	if(p4==0) {
		p4class = "보안관";
		return 0;
	}
	else if(p4==1) {
		p4class = "부관";
		return 1;
	}
	else if(p4==2) {
		p4class = "무법자";
		return 2;
	}
	else if(p4==3) {
		p4class = "배신자";
		return 3;
	}
	else {
		error = "잘못된 값이 들어왔습니다.";
		return 100;
	}
	
}
	
public int Player1classshow(String a) {
	
	
	
	return 0;
}
	
	public void PlayerclassShow() {
		
		
		
		if(p1==0) {
			p1class = "보안관";
		}
		else if(p1==1) {
			p1class = "부관";
		}
		else if(p1==2) {
			p1class = "무법자";
		}
		else if(p1==3) {
			p1class = "배신자";
		}
		else {
			System.out.println("잘못된 값이 들어왔습니다.");
		}
		
		if(p2==0) {
			p2class = "보안관";
		}
		else if(p2==1) {
			p2class = "부관";
		}
		else if(p2==2) {
			p2class = "무법자";
		}
		else if(p2==3) {
			p2class = "배신자";
		}
		else {
			System.out.println("잘못된 값이 들어왔습니다.");
		}
		
		if(p3==0) {
			p3class = "보안관";
		}
		else if(p3==1) {
			p3class = "부관";
		}
		else if(p3==2) {
			p3class = "무법자";
		}
		else if(p3==3) {
			p3class = "배신자";
		}
		else {
			System.out.println("잘못된 값이 들어왔습니다.");
		}
		
		if(p4==0) {
			p4class = "보안관";
		}
		else if(p4==1) {
			p4class = "부관";
		}
		else if(p4==2) {
			p4class = "무법자";
		}
		else if(p4==3) {
			p4class = "배신자";
		}
		else {
			System.out.println("잘못된 값이 들어왔습니다.");
		}
		
		
		
		
	}
	
	

}
