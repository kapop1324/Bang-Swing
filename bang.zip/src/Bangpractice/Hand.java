package Bangpractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

 class Hand {
	int p1hp;
	int p2hp;
	int p3hp;
	int p4hp;
	
	
	int[] p1hand = {0,0,0,0,0,0,0,0,0,0};
	int[] p2hand = {0,0,0,0,0,0,0,0,0,0};
	int[] p3hand = {0,0,0,0,0,0,0,0,0,0};
	int[] p4hand = {0,0,0,0,0,0,0,0,0,0};

	
	int i;
	
	String react;
	String who;
	String whop;
	String whos;
	

	
	public void Firsthandp(int a, int b , int c, int d) {
		
		for(i=0; i<a ; i++) {
			p1hand[i] = (int)(Math.random()*2+1);
		}
		
		for(i=0; i<b ; i++) {
			p2hand[i] = (int)(Math.random()*2+1);}
		for(i=0; i<c ; i++) {
			p3hand[i] = (int)(Math.random()*2+1);
			System.out.print(p3hand[i]);}
		for(i=0; i<d ; i++) {
			p4hand[i] = (int)(Math.random()*2+1);
			System.out.print(p4hand[i]);}
		
	}
	
	
	public int Player1Hand() {
		 int num2 = 0;
		 int sum;
	        sum =   p1hand[0]*10*10*10*10*10+
	        		p1hand[1]*10*10*10*10+
	        		p1hand[2]*10*10*10+
	        		p1hand[3]*10*10+
	        		p1hand[4]*10+
	        		p1hand[5];
	        		
	        
			return sum;
	        
			
			
		
	
		
	}
	
	public int Player2Hand() {
		 int sum;
	        sum =   p2hand[0]*10*10*10*10*10+
	        		p2hand[1]*10*10*10*10+
	        		p2hand[2]*10*10*10+
	        		p2hand[3]*10*10+
	        		p2hand[4]*10+
	        		p2hand[5];
	        		
	        
			return sum;
	        
	}
	
	public int Player3Hand() {
		 int sum;
	        sum =   p3hand[0]*10*10*10*10*10+
	        		p3hand[1]*10*10*10*10+
	        		p3hand[2]*10*10*10+
	        		p3hand[3]*10*10+
	        		p3hand[4]*10+
	        		p3hand[5];
	        		
	        
			return sum;
	        
	}
	
	public int Player4Hand() {
		 int sum;
	        sum =   p4hand[0]*10*10*10*10*10+
	        		p4hand[1]*10*10*10*10+
	        		p4hand[2]*10*10*10+
	        		p4hand[3]*10*10+
	        		p4hand[4]*10+
	        		p4hand[5];
	        		
	        
			return sum;
	        
	}
	
	public void Draw(String a) {
		
		who = a;
		
		if(who == "p1") {
			for(i=0;i<6;i++) {
				if(p1hand[i]==0) {
					p1hand[i] = (int)(Math.random()*2+1);
					break;
				}
			
			}
		}
		
		else if(who == "p2") {
			for(i=0;i<10;i++) {
				if(p2hand[i]==0) {
					p2hand[i] = (int)(Math.random()*2+1);
					break;
				}
			
			}
		}
		
		else if(who=="p3") {
			for(i=0;i<10;i++) {
				if(p3hand[i]==0) {
					p3hand[i] = (int)(Math.random()*2+1);
					break;
				}
			}
			
		}
		else {
			for(i=0;i<10;i++) {
				if(p4hand[i]==0) {
					p4hand[i] = (int)(Math.random()*2+1);
					break;
				}
			
			}
			
		}
		
	}
	
	public void Playerhand(String ab) {
		whop = ab;
		
		if(whop == "p1") {
			System.out.print("p1의 패 : ");
			for(i=0; i<5 ; i++) {
				
				System.out.print(p1hand[i]);
				
			}System.out.println("");
		}
		
		else if(whop == "p2") {
			System.out.print("p2의 패 : ");
			for(i=0; i<10 ; i++) {
				
				System.out.print(p2hand[i]);
				
			}System.out.println("");
		}
		
		else if(whop == "p3") {
			System.out.print("p3의 패 : ");
			for(i=0; i<10 ; i++) {
				
				System.out.print(p3hand[i]);
				
			}System.out.println("");
		}
		
		else {
			System.out.print("p4의 패 : ");
			for(i=0; i<10 ; i++) {
				
				System.out.print(p4hand[i]);
				
			}System.out.println("");
		}
		
		
		
	}
	
	
	
	public String Reactionhand(String a) {
		
		react = a;
		
		if(react == "p1") {
			System.out.print("p1의 패 :");
			for(i=0; i<10 ; i++) {
			
				System.out.print(p1hand[i]);
				
			}System.out.println("");
		}
		
		else if(react == "p2") {
			System.out.print("p2의 패 :");
			for(i=0; i<10 ; i++) {
				
				System.out.print(p2hand[i]);
				
			}System.out.println("");
		}
		
		else if(react == "p3") {
			System.out.print("p3의 패 :");
			for(i=0; i<10 ; i++) {
				
				System.out.print(p3hand[i]);
				
			}System.out.println("");
		}
		
		else {
			System.out.print("p4의 패 :");
			for(i=0; i<10 ; i++) {
				
				System.out.print(p4hand[i]);
				
			}System.out.println("");
		}
		
		
		
		return a;
	}
	
	public void Usecardnumber(String as ,int af) {
		
		whos = as;
		
		if(af == 10) {
			return;
		}
		else {
			if(as == "p1") {
				p1hand[af] = 0;
			}
			else if (as == "p2") {
				p2hand[af] = 0;
			}
			else if (as == "p3") {
				p3hand[af] = 0;
			}
			else {
				p4hand[af] = 0;
				
			}
		}
		
		
		
		
	}
	
int a;
	
	public int Usecard(String as ,int af) {
		
		whos = as;
		
		if(af==10) {
			return 0;
			
		}
		else {
			
			if(as == "p1") {
				if(p1hand[af]==1) {
					a=1;
				}else {
					a=2;
				}
				return a;
				
			}
			else if (as == "p2") {
				if(p2hand[af]==1) {
					a=1;
				}else {
					a=2;
				}
				return a;
				
			}
			else if (as == "p3") {
				if(p3hand[af]==1) {
					a=1;
				}else {
					a=2;
				}
				return a;
				
			}
			else {
				if(p4hand[af]==1) {
					a=1;
				}else {
					a=2;
				}
				return a;
				
			}
			
		}
		
		
	}
	Scanner sc = new  Scanner(System.in);
	
	
	public int handcheck(String as, int af, int ah) {
		
		if(as == "p1") {
		
		if(p1hand.length > ah) {
			return 1;
		}
		
		if(as == "p2") {
			
			if(p2hand.length > ah) {
				return 1;
			}
		
		if(as == "p3") {
			
			if(p3hand.length > ah) {
				return 1;
				}
			}
		
		
		if(as == "p4") {
			
			if(p4hand.length > ah) {
				return 1;
				}
			}
	}

		}
		
		return 0;
	}
	int abc;
	public void handdiscard(String as, int af, int ah) {
		
		
		if(ah == 1) {
		System.out.println("카드를 버려주세요");
		abc = sc.nextInt();		
		p1hand[abc] = 0;
		}
		
		if(ah == 1) {
			System.out.println("카드를 버려주세요");
			abc = sc.nextInt();		
			p1hand[abc] = 0;
			}
		
		if(ah == 1) {
			System.out.println("카드를 버려주세요");
			abc = sc.nextInt();		
			p1hand[abc] = 0;
			}
		
		if(ah == 1) {
			System.out.println("카드를 버려주세요");
			abc = sc.nextInt();		
			p1hand[abc] = 0;
			}
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
}
