package Bangpractice;

import java.util.Scanner;

public class Reaction {
	
	String first, second, third, fourth;	
	
	Reaction(String a, String b, String c, String d){
		
		first = a;
		second = b;
		third = c;
		fourth = d;
		
	}
	
	Scanner sc = new Scanner(System.in);
	
	String react;
	
	public String Firstwho(String a) {
		react = a;
		System.out.println(react+"님"+first+"에게 지목되었습니다.");
		return react;
	}
	
	public String Secondwho(String a) {
		react = a;
		System.out.println(react+"님"+second+"에게 지목되었습니다.");
		return react;
	}
	
	public String Thirdwho(String a) {
		react = a;
		System.out.println(react+"님"+third+"에게 지목되었습니다.");
		return react;
	}
	
	public String Fourthwho(String a) {
		react = a;
		System.out.println(react+"님"+fourth+"에게 지목되었습니다.");
		return react;
	}
	
	int intput;
	
	public int Firstreaction(String a) {
		react = a;
		
		System.out.println("카드사용 : 0~9 넘어가기 : 10");
		 intput = sc.nextInt();
	
		
		return intput;
	}
	
	public 	int Secondreaction(String a) {
		react = a;
		
		System.out.println("카드사용 : 0~9 넘어가기 : 10");
		 intput = sc.nextInt();
		
		return intput;
	}
	public int Thirdreaction(String a) {
		react = a;
		
		System.out.println("카드사용 : 0~9 넘어가기 : 10");
		 intput = sc.nextInt();
		
		return intput;
	}
	
	public int Fourthreaction(String a) {
		react = a;
		
		System.out.println("카드사용 : 0~9 넘어가기 : 10");
		 intput = sc.nextInt();
		
		return intput;
	}
	
	
}
