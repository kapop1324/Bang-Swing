package Bangpractice;

public class Aliveordead {

	String firstp, secondp, thirdp, fourthp;
	
	Aliveordead(String first, String second, String third, String fourth){
		firstp = first;
		secondp = second;
		thirdp = third;
		fourthp = fourth;
		
	}
	
	
	public int Aliveordead1(String p1, String p2, String p3, String p4) {
		
		if(firstp == "p1" && p1 != "alive") {
			System.out.println("p1은 사망상태입니다.");
			return 1;
		}else if(firstp == "p2" && p2 != "alive") {
			System.out.println("p2는 사망상태입니다.");
			return 1;
		}else if(firstp == "p3" && p3 != "alive") {
			System.out.println("p3는 사망상태입니다.");
			return 1;
		}else if(firstp == "p4" && p4 != "alive") {
			System.out.println("p4는 사망상태입니다.");
			return 1;
		}		
		return 0;
	}
	
	public int Aliveordead2(String p1, String p2, String p3, String p4) {
		
		if(secondp == "p1" && p1 != "alive") {
			System.out.println("p1은 사망상태입니다.");
			return 1;
		}else if(secondp == "p2" && p2 != "alive") {
			System.out.println("p2는 사망상태입니다.");
			return 1;
		}else if(secondp == "p3" && p3 != "alive") {
			System.out.println("p3는 사망상태입니다.");
			return 1;
		}else if(secondp == "p4" && p4 != "alive") {
			System.out.println("p4는 사망상태입니다.");
			return 1;
		}
		
		return 0;
		
		
	}

	public int Aliveordead3(String p1, String p2, String p3, String p4) {
	
		if(thirdp == "p1" && p1 != "alive") {
			System.out.println("p1은 사망상태입니다.");
			return 1;
		}else if(thirdp == "p2" && p2 != "alive") {
			System.out.println("p2는 사망상태입니다.");
			return 1;
		}else if(thirdp == "p3" && p3 != "alive") {
			System.out.println("p3는 사망상태입니다.");
			return 1;
		}else if(thirdp == "p4" && p4 != "alive") {
			System.out.println("p4는 사망상태입니다.");
			return 1;
		}
	
		return 0;
	
	
	}

	public int Aliveordead4(String p1, String p2, String p3, String p4) {
	
		if(fourthp == "p1" && p1 != "alive") {
			System.out.println("p1은 사망상태입니다.");
			return 1;
		}else if(fourthp == "p2" && p2 != "alive") {
			System.out.println("p2는 사망상태입니다.");
			return 1;
		}else if(fourthp == "p3" && p3 != "alive") {
			System.out.println("p3는 사망상태입니다.");
			return 1;
		}else if(fourthp == "p4" && p4 != "alive") {
			System.out.println("p4는 사망상태입니다.");
			return 1;
		}
		return 0;
	
	
	
	}
	
	
}
