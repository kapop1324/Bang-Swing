package Bangpractice;

public class Ad {
	
	public String Ad(String a) {
		
		return a;
	}
	
	
}
