package Bangpractice;

import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;




public class Client extends JFrame {

	
	private JTextField tf_ID; // ID�� �Է¹�����
	private JTextField tf_IP; // IP�� �Է¹�����
	private JTextField tf_PORT; //PORT�� �Է¹�����
	ImageIcon i = new ImageIcon("C:\\Users\\user\\Downloads\\kongimg\\hi.jpg");
    Image im=i.getImage();
    
	public Client() // ������
	{

		init();
		start();

	}

	public void init() // ȭ�� ����
	{
		
		MyPanel panel = new MyPanel();
        panel.setLayout(new FlowLayout());
		
        this.setTitle("bang");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
		
		

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(53, 77, 90, 34);
		this.getContentPane().add(lblNewLabel);

		tf_ID = new JTextField();
		tf_ID.setBounds(92, 84, 150, 21);
		this.getContentPane().add(tf_ID);
		tf_ID.setColumns(10);

		JLabel lblServerIp = new JLabel("Server IP");
		lblServerIp.setBounds(12, 131, 90, 34);
		this.getContentPane().add(lblServerIp);

		tf_IP = new JTextField();
		tf_IP.setColumns(10);
		tf_IP.setBounds(92, 138, 150, 21);
		this.getContentPane().add(tf_IP);

		JLabel lblPort = new JLabel("Port");
		lblPort.setBounds(36, 198, 90, 34);
		this.getContentPane().add(lblPort);

		tf_PORT = new JTextField();
		tf_PORT.setColumns(10);
		tf_PORT.setBounds(92, 205, 150, 21);
		this.getContentPane().add(tf_PORT);

		JButton btnNewButton = new JButton("접속");
		btnNewButton.setBounds(36, 330, 100, 52);
		this.getContentPane().add(btnNewButton);
		
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				String _id = tf_ID.getText().trim();
				String _ip= tf_IP.getText().trim(); 
				int _port=Integer.parseInt(tf_PORT.getText().trim());  
				
				MainView view = new MainView(_id,_ip,_port);
				setVisible(false);
				
				
			}
		});
		
		this.add(panel);
		this.setSize(400, 500);
		this.setVisible(true);
	}

	public void start() // �̺�Ʈ ó��
	{

	}
	class MyPanel extends JPanel{
        
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            g.drawImage(im,0,0,getWidth(),getHeight(),this);
        }
    }
}

