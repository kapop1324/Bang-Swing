package Bangpractice;

public class Playerhp {
	int p1hp, p2hp, p3hp, p4hp;
	int p1rcn,p2rcn,p3rcn,p4rcn;
	
	public Playerhp() {
	
		
	}

	public int Player1hp(int a) {

		if(a == 0) {
			p1hp = 4;
			return 4;
		}
		else if(a == 1) {
			p1hp = 4;
			return 4;
		}
		else if(a == 2) {
			p1hp = 3;
			return 3;
		}
		else if(a == 3) {
			p1hp = 4;
			return 4;
		}
		else if(a == 4) {
			p1hp = 4;
			return 4;
		}
		else if(a == 5) {
			p1hp = 4;
			return 4;
		}
		else if(a == 6) {
			p1hp = 4;
			return 4;
		}
		else if(a == 7) {
			p1hp = 4;
			return 4;
		}
		else {
			System.out.println("오류 발생");
			return 0;
		}
	}
	
	public int Player2hp(int a) {
		if(a == 0) {
			p2hp = 4;
			return 4;
		}
		else if(a == 1) {
			p2hp = 4;
			return 4;
		}
		else if(a== 2) {
			p2hp = 3;
			return 3;
		}
		else if(a == 3) {
			p2hp = 4;
			return 4;
		}
		else if(a == 4) {
			p2hp = 4;
			return 4;
		}
		else if(a == 5) {
			p2hp = 4;
			return 4;
		}
		else if(a == 6) {
			p2hp = 4;
			return 4;
		}
		else if(a == 7) {
			p2hp = 4;
			return 4;
		}
		else {
			System.out.println("오류 발생");
			return 0;
		}
	}
	
	public int Player3hp(int a) {
		if(a == 0) {
			p3hp = 4;
			return 4;
		}
		else if(a == 1) {
			p3hp = 4;
			return 4;
		}
		else if(a == 2) {
			p3hp = 3;
			return 3;
		}
		else if(a == 3) {
			p3hp = 4;
			return 4;
		}
		else if(a == 4) {
			p3hp = 4;
			return 4;
		}
		else if(a == 5) {
			p3hp = 4;
			return 4;
		}
		else if(a == 6) {
			p3hp = 4;
			return 4;
		}
		else if(a == 7) {
			p3hp = 4;
			return 4;
		}
		else {
			System.out.println("오류 발생");
			return 0;
		}
		
	}
	public int Player4hp(int a) {

		if(a == 0) {
			p4hp = 4;
			return 4;
		}
		else if(a == 1) {
			p4hp = 4;
			return 4;
		}
		else if(a == 2) {
			p4hp = 3;
			return 3;
		}
		else if(a == 3) {
			p4hp = 4;
			return 4;
		}
		else if(a == 4) {
			p4hp = 4;
			return 4;
		}
		else if(a == 5) {
			p4hp = 4;
			return 4;
		}
		else if(a == 6) {
			p4hp = 4;
			return 4;
		}
		else if(a == 7) {
			p4hp = 4;
			return 4;
		}
		else {
			System.out.println("오류 발생");
			return 0;
		}
	}
	

	public void Playerhp() {
		
		
		
		
		
		
	}

}
