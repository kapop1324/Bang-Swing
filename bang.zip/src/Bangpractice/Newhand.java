package Bangpractice;

public class Newhand {
	

	int p1bang;
	int p1exit;
	int p2bang;
	int p2exit;
	int p3bang;
	int p3exit;
	int p4bang;
	int p4exit;
	int p1hp= 0;
	int p2hp=0;
	int p3hp=0;
	int p4hp=0;
	int p1bangdraw;
	int p2bangdraw;
	int p3bangdraw;
	int p4bangdraw;
	int p1exitdraw;
	int p2exitdraw;
	int p3exitdraw;
	int p4exitdraw;
	
	public void Draw() {
		
		p1bang = (int)(Math.random()*1);
		p1exit = (int)(Math.random()*1);
		p2bang = (int)(Math.random()*1);
		p2exit = (int)(Math.random()*1);
		p3bang = (int)(Math.random()*1);
		p3exit = (int)(Math.random()*1);
		p4bang = (int)(Math.random()*1);
		p4exit = (int)(Math.random()*1);
		
		if((p1bang + p1exit)<p1hp) {
			
		}
		

		if((p2bang + p2exit)<p2hp) {	
	
		}

		if((p3bang + p3exit)<p3hp) {
	
		}

		if((p4bang + p4exit)<p4hp) {
	
		}
		
		
	}
	
	
	public void Newhand() {
		
		
		
		p1bang = (int)(Math.random()*4+1);
		p1exit = (int)(Math.random()*4+1);
		p2bang = (int)(Math.random()*4+1);
		p2exit = (int)(Math.random()*4+1);
		p3bang = (int)(Math.random()*4+1);
		p3exit = (int)(Math.random()*4+1);
		p4bang = (int)(Math.random()*4+1);
		p4exit = (int)(Math.random()*4+1);
		
		if((p1bang + p1exit)<p1hp) {
			
		}
		

		if((p2bang + p2exit)<p2hp) {	
	
		}

		if((p3bang + p3exit)<p3hp) {
	
		}

		if((p4bang + p4exit)<p4hp) {
	
		}
		

	}

}
