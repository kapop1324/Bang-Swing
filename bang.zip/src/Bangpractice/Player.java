package Bangpractice;

public class Player {
	int p1rhp1;
	int p1hp1;
	int p1rh1;
	int p1distance = 1;
	String p1class1;
	String p1character1;
	
	int p2rhp2;
	int p2hp2;
	int p2rh2;
	int p2distance = 1;
	String p2class2;
	String p2character2;
	
	int p3rhp3;
	int p3hp3;
	int p3rh3;
	int p3distance = 1;
	String p3class3;
	String p3character3;
	
	int p4rhp4;
	int p4hp4;
	int p4rh4;
	int p4distance = 1;
	String p4class4;
	String p4character4;
	
	
	public int Player1(int p1class,  int p1hp) {
		
		 
		if(p1class == 0) {
			p1hp = p1hp + 1;
			
			
			return p1hp;
			
		}
		else {
			p1hp = p1hp;
			
			
			return p1hp;
		}
		
		
	}
	
	public int Player2(int p2class, int p2hp) {
	
		if(p2class == 0) {
			p2hp = p2hp + 1;
			
			
			
			return p2hp;
		}
		else {
			p2hp = p2hp;
			
			
			return p2hp;
		}
		
		
	}
	
	public int Player3(int p3class,  int p3hp) {
		
		 
		if(p3class == 0) {
			p3hp = p3hp + 1;
			
			
			return p3hp;
		}
		else {
			p3hp = p3hp;
		
			
			return p3hp;
		}
	
	
	}
	
	public int Player4(int p4class,int p4hp) {
		
		if(p4class == 0) {
			p4hp = p4hp + 1;
			
			return p4hp;
		}
		else {
			p4hp = p4hp;
			
		
			
			return p4hp;
		}
	
	
	}
	
	
	public void firstplayer() {
		
	}
	
	public void secondplayer() {
		
	}
	
	public void thirdplayer() {
		
	}
	
	public void fourthplayer() {
		
	}
	
	
}
