package Bangpractice;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;





public class Game  {
	
	/*
	public void Newgame() {
		String p1class,p2class,p3class,p4class;
		String p1character,p2character,p3character,p4character;
		int p1hp,p2hp,p3hp,p4hp;
		Playerclass pcl = new Playerclass();
		
		//pcl.Playerclass();
		//p1class = pcl.p1class;
		//p1class = pcl.Player1calss();
	}
	
	
	
		
	public void Game() {
		String p1class,p2class,p3class,p4class;
		String p1character,p2character,p3character,p4character;
		int p1hp,p2hp,p3hp,p4hp;
		
		
		
		Playerclass pcl = new Playerclass();
		//pcl.Playerclass();
		pcl.PlayerclassShow();
		
		Playercharacter pcr = new Playercharacter();
		//pcr.Playercharacter();
		pcr.Playercharactershow();
		int p1cn = pcr.p1;
		int p2cn = pcr.p2;
		int p3cn = pcr.p3;
		int p4cn = pcr.p4;
		
		Playerhp php = new Playerhp();
		php.Playerhp();
		
		int p1rh = pcl.p1;;
		int p2rh = pcl.p2;;
		int p3rh = pcl.p3;;
		int p4rh = pcl.p4;;
		
		int p1rhp = 0;
		int p2rhp = 0;
		int p3rhp = 0;
		int p4rhp = 0;
		
		Player p = new Player();
		p1class = pcl.p1class;
		p1character = pcr.p1character;
		p1hp = php.p1hp;
		//int rhp1 = p.Player1(p1class,p1character,p1rhp,p1rh,p1hp);
		//p1rhp = rhp1;
		
		

		p2class = pcl.p2class;
		p2character = pcr.p2character;
		p2hp = php.p2hp;
		//int rhp2 = p.Player2(p2class,p2character,p2rhp,p2rh,p2hp);
	//	p2rhp = rhp2;
		
		p3class = pcl.p3class;
		p3character = pcr.p3character;
		p3hp = php.p3hp;
	//	int rhp3 = p.Player3(p3class,p3character,p3rhp,p3rh,p3hp);
	//	p3rhp = rhp3;
		
		p4class = pcl.p4class;
		p4character = pcr.p4character;
		p4hp = php.p4hp;
	//	int rhp4 = p.Player4(p4class,p4character,p4rhp,p4rh,p4hp);
	//	p4rhp = rhp4;
		
		
		
		
		
		Turnnumber tn = new Turnnumber(pcl.p1,pcl.p2,pcl.p3,pcl.p4);
		
		int p1tn = tn.p1;
		int p2tn = tn.p2;
		int p3tn = tn.p3;
		int p4tn = tn.p4;
		
		
		Turn tr= new Turn(tn.p1number,tn.p2number,tn.p3number,tn.p4number);
		tr.Turn();
		
		Hand hd = new Hand();
		
		
		Turnchoice tc = new Turnchoice( p1tn, p2tn, p3tn, p4tn);
		Turnloop tl = new Turnloop();
		Duel c = new Duel(p1rhp, p2rhp, p3rhp, p4rhp);
		String firstch = tc.first;
		String secondch = tc.second;
		String thirdch = tc.third;
		String fourthch = tc.fourth;
		Peoplechoice pec = new Peoplechoice(firstch,secondch,thirdch,fourthch);
		Reaction rec = new Reaction(firstch,secondch,thirdch,fourthch);
		
		
		
		int resultp1hp = c.p1hp;
		int resultp2hp = c.p2hp;
		int resultp3hp = c.p3hp;
		int resultp4hp = c.p4hp;
		
		String p1dead;
		String p2dead;
		String p3dead;
		String p4dead;
		int gameover;
		p1dead= c.p1dead();
		p2dead = c.p2dead();
		p3dead = c.p3dead();
		p4dead= c.p4dead();
		gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);
		Aliveordead ad = new Aliveordead(firstch, secondch, thirdch, fourthch);
		
		 do{	
				
				
				
				
				int ad1 = ad.Aliveordead1(p1dead,p2dead,p3dead,p4dead);	
				if(ad1 == 0) {
					int tc1 = tc.Choice1();

					
					if(tc1 == 1) {
				
				hd.Draw(firstch);
				hd.Playerhand(firstch);	11	12
				int tl1 = tl.Turnloop();
				String pec1 = pec.Firstplayerchoice();
				rec.Firstwho(pec1);
				hd.Reactionhand(pec1);
				int recc1 = rec.Firstreaction(pec1);
				int us1 = hd.Usecard(firstch, tl1);
				hd.Usecardnumber(firstch,tl1);
				hd.Playerhand(firstch);
				hd.Usecardnumber(pec1,recc1);
				int rs1 = hd.Usecard(pec1, recc1);
				hd.Playerhand(pec1);
				int duelresult1 = c.Duel(us1,rs1);
				int hp1 = c.duelhp(firstch,pec1,duelresult1);
				c.resulthp();
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);
				
				
			}

			else {
				hd.Draw(firstch);
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);	
				
				
				}
			}
			else {
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);	
				

				}





			int ad2 = ad.Aliveordead2(p1dead,p2dead,p3dead,p4dead);	
			if(ad2 == 0) {

			int tc2 = tc.Choice2();

			if(tc2 == 1) {
				
				hd.Draw(secondch);
				hd.Playerhand(secondch);	
				int tl2 = tl.Turnloop();
				String pec2 = pec.Secondplayerchoice();
				rec.Secondwho(pec2);
				hd.Reactionhand(pec2);
				int recc2 = rec.Secondreaction(pec2);
				int us2 = hd.Usecard(secondch, tl2);
				hd.Usecardnumber(secondch,tl2);
				hd.Playerhand(secondch);
				hd.Usecardnumber(pec2,recc2);
				int rs2 = hd.Usecard(pec2, recc2);
				hd.Playerhand(pec2);
				int  duelresult2 = c.Duel(us2,rs2);
				int hp2 = c.duelhp(secondch,pec2,duelresult2);
				c.resulthp();

				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);
				
				
			}
			else {
				hd.Draw(secondch);
				
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);	
				
				
				}
			}
			else {
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);	
				
			}




			int ad3 = ad.Aliveordead3(p1dead,p2dead,p3dead,p4dead);	
			if(ad3 == 0) {

			int tc3 = tc.Choice3();

			if(tc3 == 1) {
				
				hd.Draw(thirdch);
				hd.Playerhand(thirdch);	
				int tl3 = tl.Turnloop();
				String pec3 = pec.Thirdplayerchoice();
				rec.Thirdwho(pec3);
				hd.Reactionhand(pec3);
				int recc3 = rec.Thirdreaction(pec3);
				int us3 = hd.Usecard(thirdch, tl3);
				hd.Usecardnumber(thirdch,tl3);
				hd.Playerhand(thirdch);
				hd.Usecardnumber(pec3,recc3);
				int rs3 = hd.Usecard(pec3, recc3);
				hd.Playerhand(pec3);
				int duelresult3 = c.Duel(us3,rs3);
				int hp3 = c.duelhp(thirdch,pec3,duelresult3);
				c.resulthp();
				
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);		
				
				

			}
			else {
				hd.Draw(thirdch);
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);	
				
			}

			}
			else{
				
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);	
				}








			int ad4 = ad.Aliveordead4(p1dead,p2dead,p3dead,p4dead);	
			if(ad4 == 0) {


				int tc4 = tc.Choice4();
				
				if(tc4 == 1) {

					hd.Draw(fourthch);
			hd.Playerhand(fourthch);	
			int tl4 = tl.Turnloop();
			String pec4 = pec.Fourthplayerchoice();
			rec.Fourthwho(pec4);
			hd.Reactionhand(pec4);
			int recc4 = rec.Fourthreaction(pec4);
			int us4 = hd.Usecard(fourthch, tl4);
			hd.Usecardnumber(fourthch,tl4);
			hd.Playerhand(fourthch);
			hd.Usecardnumber(pec4,recc4);
			int rs4 = hd.Usecard(pec4, recc4);
			hd.Playerhand(pec4);
			int duelresult4 = c.Duel(us4,rs4);
			int hp4 = c.duelhp(fourthch,pec4,duelresult4);
			c.resulthp();

			p1dead= c.p1dead(p1class);
			p2dead = c.p2dead(p2class);
			p3dead = c.p3dead(p3class);
			p4dead= c.p4dead(p4class);
			gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);		



			}
			else {
			hd.Draw(fourthch);
			p1dead= c.p1dead(p1class);
			p2dead = c.p2dead(p2class);
			p3dead = c.p3dead(p3class);
			p4dead= c.p4dead(p4class);
			gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);	

			}

			}
			else {
				p1dead= c.p1dead(p1class);
				p2dead = c.p2dead(p2class);
				p3dead = c.p3dead(p3class);
				p4dead= c.p4dead(p4class);
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);	
				
			}


			}while(gameover == 0);
	}
	*/
}
	
	
	








