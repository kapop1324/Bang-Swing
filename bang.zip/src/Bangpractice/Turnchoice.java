package Bangpractice;

import java.util.Scanner;

public class Turnchoice {
	
	int p1, p2, p3, p4;
	
	String first, second, third, fourth;
	
	int input; 
	
	 Turnchoice(int p1tn, int p2tn, int p3tn, int p4tn) {
		
		p1 = p1tn;
		p2 = p2tn;
		p3 = p3tn;
		p4 = p4tn;
		
		if(p1 == 0) {
			first = "p1";
			second = "p2";
			third = "p3";
			fourth = "p4";
		}
		else if (p2 == 0) {
			first = "p2";
			second = "p3";
			third = "p4";
			fourth = "p1";
		}
		else if (p3 == 0) {
			first = "p3";
			second = "p4";
			third = "p1";
			fourth = "p2";
		}
		else{
			first = "p4";
			second = "p1";
			third = "p2";
			fourth = "p3";
		}
		
	}
	
	public int Choice1() {
		Scanner sc = new Scanner(System.in);
		System.out.println("보안관인 "+first+ "의 순서입니다.");
		System.out.println("행동을 선택하십시오 카드선택 : 1 넘어가기 : 2");
		input = sc.nextInt();
		if(input == 1) {
			return 1;
		}
		else if(input == 2) {
			return 2;
		}
		else {
			return 0;
		}
		
	}
	
	public int Choice2() {
		Scanner sc = new Scanner(System.in);
		System.out.println("2번플레이어 "+second+"  의 순서입니다.");
		System.out.println("행동을 선택하십시오 카드선택 : 1 넘어가기 : 2");
		input = sc.nextInt();
		if(input == 1) {
			return 1;
		}
		else if(input == 2) {
			return 2;
		}
		else {
			return 0;
		}
		
	}
	
	public int Choice3() {
		Scanner sc = new Scanner(System.in);
		System.out.println("3번플레이어 "+third+"의순서입니다.");
		System.out.println("행동을 선택하십시오 카드선택 : 1 넘어가기 : 2");
		input = sc.nextInt();
		if(input == 1) {
			return 1;
		}
		else if(input == 2) {
			return 2;
		}
		else {
			return 0;
		}
		
	}
	
	public int Choice4() {
		Scanner sc = new Scanner(System.in);
		System.out.println("4번플레이어 "+fourth+"의 순서입니다.");
		System.out.println("행동을 선택하십시오 카드선택 : 1 넘어가기 : 2");
		input = sc.nextInt();
		if(input == 1) {
			return 1;
		}
		else if(input == 2) {
			return 2;
		}
		else {
			return 0;
		}
		
	}
	
	
}
