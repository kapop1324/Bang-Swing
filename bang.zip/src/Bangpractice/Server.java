package Bangpractice;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.logging.Handler;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class Server extends JFrame {

	private JPanel contentPane;
	private JTextField textField; 
	private JButton Start; 
	JTextArea textArea; 

	private ServerSocket socket; 
	private Socket soc; 
	private Socket soc2;
	private int Port; 

	private Vector vc = new Vector(); 

	
	
	
	
	public static void main(String[] args)
	{
	
					Server frame = new Server();
					frame.setVisible(true);
			
	}

	public Server() {

		init();
		
		
		
	}

	private void init() { 
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 280, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		
		JScrollPane js = new JScrollPane();
				
		textArea = new JTextArea();
		textArea.setColumns(20);
		textArea.setRows(5);
		
		js.setBounds(0, 0, 264, 254);
		contentPane.add(js);
		js.setViewportView(textArea);

		textField = new JTextField();
		textField.setBounds(98, 264, 154, 37);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel = new JLabel("Port Number");
		lblNewLabel.setBounds(12, 264, 98, 37);
		contentPane.add(lblNewLabel);

		Start = new JButton("포트접속하기");

		Start.addActionListener(new ActionListener() { 

			@Override
			public void actionPerformed(ActionEvent e) {
								
				if (textField.getText().equals("") || textField.getText().length()==0)
				{
					textField.setText("텍스트필드");
					textField.requestFocus(); 
				} 
				
				else 
				{
					try
					{
					Port = Integer.parseInt(textField.getText()); 
					
					server_start(); 
					
				
					
					}
					catch(Exception er)
					{
						
						textField.setText("텍스트필드");
						textField.requestFocus(); 
					}
		
					
				
				}

			}
		});

		Start.setBounds(0, 325, 264, 37);
		contentPane.add(Start);
		
		
		textArea.setEditable(false); 
		
	}

	private void server_start() {

		

		try {
			socket = new ServerSocket(Port);
			Start.setText("스타트");
			Start.setEnabled(false); 
			textField.setEnabled(false); 
			
			if(socket!=null) 
			{
			Connection();
			}
			
		} catch (IOException e) {
			textArea.append("음3...\n");

		}

	}
	
	public void Connection() {
		
		Thread th = new Thread(new Runnable() {
			int count=1;
			
			@Override
			public void run() {
				int p1class,p2class,p3class,p4class;
				int p1character,p2character,p3character,p4character;
				int p1hp = 0,p2hp = 0,p3hp = 0,p4hp = 0;
				int p1tn,p2tn,p3tn,p4tn;
				String first = null,second=null,third=null,fourth=null;
				int p1hd;
				int  p2hd,p3hd,p4hd;
				int gamestart = 0;
				Playerclass pcl = new Playerclass();
				Playercharacter pcr = new Playercharacter();
				Playerhp php = new Playerhp(); 
							
				
				while(true) {
					
					
						
					
					try {
						textArea.append("인원 대기중입니다...\n");
						soc = socket.accept(); 
	
						textArea.append(count+"번째 유저가 접속했습니다.");
					
						UserInfo user = new UserInfo(soc, vc); 
						
						vc.add(user); 
						String nick = user.Nickname;
						user.start(); 
					
						
						
						user.checkAccess();
						
						p1class = pcl.Player1class();
						p2class = pcl.Player2class();
						p3class = pcl.Player3class();
						p4class = pcl.Player4class();
						
						p1character = pcr.Playercharcter1();
						p2character = pcr.Playercharcter2();
						p3character = pcr.Playercharcter3();
						p4character = pcr.Playercharcter4();
						
						p1hp = php.Player1hp(p1character);
						p2hp = php.Player2hp(p2character);
						p3hp = php.Player3hp(p3character);
						p4hp = php.Player4hp(p4character);
						
						Player p = new Player();
						p1hp = p.Player1(p1class,p1hp);
						p2hp = p.Player2(p2class,p2hp);
						p3hp = p.Player3(p3class,p3hp);
						p4hp = p.Player4(p4class,p4hp);
						
						Turnnumber tn = new Turnnumber(p1class,p2class,p3class,p4class);
					
						
						p1tn =tn.Player1turnnumber();
						p2tn =tn.Player2turnnumber();
						p3tn =tn.Player3turnnumber();
						p4tn =tn.Player4turnnumber();
						
						if(p1tn == 1) {
							first = "p1";
						}
						else if(p1tn == 2) {
							second = "p1";
						}
						else if(p1tn == 3) {
							third = "p1";
						}
						else if(p1tn == 4) {
							fourth = "p1";
						}
						
						if(p2tn == 1) {
							first = "p2";
						}
						else if(p2tn == 2) {
							second = "p2";
						}
						else if(p2tn == 3) {
							third = "p2";
						}
						else if(p2tn == 4) {
							fourth = "p2";
						}
						
						if(p3tn == 1) {
							first = "p3";
						}
						else if(p3tn == 2) {
							second = "p3";
						}
						else if(p3tn == 3) {
							third = "p3";
						}
						else if(p3tn == 4) {
							fourth = "p3";
						}
						
						if(p4tn == 1) {
							first = "p4";
						}
						else if(p4tn == 2) {
							second = "p4";
						}
						else if(p4tn == 3) {
							third = "p4";
						}
						else if(p4tn == 4) {
							fourth = "p4";
						}
						
						Hand hd = new Hand();
						
						hd.Firsthandp(p1hp,p2hp,p3hp,p4hp);
						
						int p111hd = hd.Player1Hand();
						String p11hd = String.valueOf(p111hd);
						
						int p222hd = hd.Player2Hand();
						String p22hd = String.valueOf(p222hd);
						
						int p333hd = hd.Player3Hand();
						String p33hd = Integer.toString(p333hd);
						
						int p444hd = hd.Player4Hand();
						String p44hd = Integer.toString(p444hd);		
						
						Turn tr = new Turn(p1tn,p2tn,p3tn,p4tn);
						tr.Turn();
						
						Turnchoice tc = new Turnchoice(p1tn,p2tn,p3tn,p4tn);
						Turnloop tl = new Turnloop();
						Duel c = new Duel(p1hp, p2hp, p3hp, p4hp);
						
						Peoplechoice pec = new Peoplechoice(first,second,third,fourth);
						Reaction rec = new Reaction(first,second,third,fourth);
						
						int resultp1hp = c.p1hp;
						int resultp2hp = c.p2hp;
						int resultp3hp = c.p3hp;
						int resultp4hp = c.p4hp;
						
						String p1dead;
						String p2dead;
						String p3dead;
						String p4dead;
						int gameover;
						p1dead= c.p1dead();
						p2dead = c.p2dead();
						p3dead = c.p3dead();
						p4dead= c.p4dead();
						gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);
						Aliveordead ad = new Aliveordead(first, second, third, fourth);
						
						//first second third fourth p1hp p2hp p3hp p4hp p1dead p2dead p3dead p4dead
					
						
						
						textArea.append("1번 : "+first+" 2번 : "+second+" 3번 : "+third+" 4번 : "+fourth+".\n");
						textArea.append("p1 생존여부 : "+p1dead+" "+"p2 생존여부 : "+p2dead+" "+"p3 생존여부 : "+p3dead+" "+"p4 생존여부 : "+p4dead+".\n");

					
						
						
								
								
						
							
								
								
							
					
						
						
						
						if(count==1) {

							if(p1class == 0) {
								textArea.append(nick+"의 직업은 보안관 입니다.\n");
								user.classresult(p1class);
								textArea.append(nick+"의 순서는 "+p1tn+"번입니다.\n");
								user.turnresult(p1tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
								
							}
							else if(p1class == 1) {
								textArea.append(nick+"의 직업은 부관 입니다.\n");
								user.classresult(p1class);
								textArea.append(nick+"의 순서는 "+p1tn+"번입니다.\n");
								user.turnresult(p1tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else if(p1class == 2) {
								textArea.append(nick+"의 직업은 무법자 입니다.\n");
								user.classresult(p1class);
								textArea.append(nick+"의 순서는 "+p1tn+"번입니다.\n");
								user.turnresult(p1tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else if(p1class == 3) {
								textArea.append(nick+"의 직업은 배신자 입니다.\n");
								user.classresult(p1class);
								textArea.append(nick+"의 순서는 "+p1tn+"번입니다.\n");
								user.turnresult(p1tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
							
							}
							else {
								textArea.append("에러!");
								
							}
							
							if(p1character == 0) {
								textArea.append(nick+"의 캐릭터는 윌리 더 키드입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p1hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p1character == 1) {
								textArea.append(nick+"의 캐릭터는 캘러미티 자넷입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p1hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p1character == 2) {
								textArea.append(nick+"의 캐릭터는 폴 리그레트입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p1hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p1character == 3) {
								textArea.append(nick+"의 캐릭터는 로즈 뮬란입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p1hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p1character == 4) {
								textArea.append(nick+"의 캐릭터는 슬랩 더 킬러입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p1hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p1character == 5) {
								textArea.append(nick+"의 캐릭터는 수지 라파에트입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p1hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p1character == 6) {
								textArea.append(nick+"의 캐릭터는 바트 캐시디입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p1hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p1character == 7) {
								textArea.append(nick+"의 캐릭터는 시드케첨입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p1hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							
							else {
								textArea.append("에러!");
								
							}
							count++;
							
							user.gameprogress(first,second,third,fourth,
									p1hp,p2hp,p3hp,p4hp,
									p1tn,p2tn,p3tn,p4tn,
									p111hd,p222hd,p333hd,p444hd,p1class,p2class,p3class,p4class);
						}
						
						else if(count==2) {
							
							
							
							if(p2class == 0) {
								textArea.append(nick+"의 직업은 보안관 입니다.\n");
								user.classresult(p2class);
								textArea.append(nick+"의 순서는 "+p2tn+"번입니다.\n");
								user.turnresult(p2tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else if(p2class == 1) {
								textArea.append(nick+"의 직업은 부관 입니다.\n");
								user.classresult(p2class);
								textArea.append(nick+"의 순서는 "+p2tn+"번입니다.\n");
								user.turnresult(p2tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else if(p2class == 2) {
								textArea.append(nick+"의 직업은 무법자 입니다.\n");
								user.classresult(p2class);
								textArea.append(nick+"의 순서는 "+p2tn+"번입니다.\n");
								user.turnresult(p2tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else if(p2class == 3) {
								textArea.append(nick+"의 직업은 배신자 입니다.\n");
								user.classresult(p2class);
								textArea.append(nick+"의 순서는 "+p2tn+"번입니다.\n");
								user.turnresult(p2tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else {
								textArea.append("에러!");
								
							}
							if(p2character == 0) {
								textArea.append(nick+"의 캐릭터는 윌리 더 키드입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p2hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p2character == 1) {
								textArea.append(nick+"의 캐릭터는 캘러미티 자넷입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p2hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p2character == 2) {
								textArea.append(nick+"의 캐릭터는 폴 리그레트입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p2hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p2character == 3) {
								textArea.append(nick+"의 캐릭터는 로즈 뮬란입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p2hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p2character == 4) {
								textArea.append(nick+"의 캐릭터는 슬랩 더 킬러입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p2hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p2character == 5) {
								textArea.append(nick+"의 캐릭터는 수지 라파에트입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p2hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p2character == 6) {
								textArea.append(nick+"의 캐릭터는 바트 캐시디입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p2hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p2character == 7) {
								textArea.append(nick+"의 캐릭터는 시드케첨입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p2hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							
							else {
								textArea.append("에러!");
								
							}
							count++;
							user.gameprogress(first,second,third,fourth,
									p1hp,p2hp,p3hp,p4hp,
									p1tn,p2tn,p3tn,p4tn,
									p111hd,p222hd,p333hd,p444hd,p1class,p2class,p3class,p4class);
						
						}
						else if(count==3) {
							
						
						
							if(p3class == 0) {
								textArea.append(nick+"의 직업은 보안관 입니다.\n");
								user.classresult(p3class);
								textArea.append(nick+"의 순서는 "+p3tn+"번입니다.\n");
								user.turnresult(p3tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else if(p3class == 1) {
								textArea.append(nick+"의 직업은 부관 입니다.\n");
								user.classresult(p3class);
								textArea.append(nick+"의 순서는 "+p3tn+"번입니다.\n");
								user.turnresult(p3tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else if(p3class == 2) {
								textArea.append(nick+"의 직업은 무법자 입니다.\n");
								user.classresult(p3class);
								textArea.append(nick+"의 순서는 "+p3tn+"번입니다.\n");
								user.turnresult(p3tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
							
							}
							else if(p3class == 3) {
								textArea.append(nick+"의 직업은 배신자 입니다.\n");
								user.classresult(p3class);
								textArea.append(nick+"의 순서는 "+p3tn+"번입니다.\n");
								user.turnresult(p3tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
								
							}
							else {
								textArea.append("에러!");
								
							}
							if(p3character == 0) {
								textArea.append(nick+"의 캐릭터는 윌리 더 키드입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p3hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p3character == 1) {
								textArea.append(nick+"의 캐릭터는 캘러미티 자넷입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p3hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p3character == 2) {
								textArea.append(nick+"의 캐릭터는 폴 리그레트입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p3hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p3character == 3) {
								textArea.append(nick+"의 캐릭터는 로즈 뮬란입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p3hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p3character == 4) {
								textArea.append(nick+"의 캐릭터는 슬랩 더 킬러입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p3hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p3character == 5) {
								textArea.append(nick+"의 캐릭터는 수지 라파에트입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p3hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p3character == 6) {
								textArea.append(nick+"의 캐릭터는 바트 캐시디입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p3hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p3character == 7) {
								textArea.append(nick+"의 캐릭터는 시드케첨입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p3hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							
							else {
								textArea.append("에러!");
								
							}
							count++;
							user.gameprogress(first,second,third,fourth,
									p1hp,p2hp,p3hp,p4hp,
									p1tn,p2tn,p3tn,p4tn,
									p111hd,p222hd,p333hd,p444hd,p1class,p2class,p3class,p4class);
							
						}
						else if(count==4) {
						
							if(p4class == 0) {
								textArea.append(nick+"의 직업은 보안관 입니다.\n");
								user.classresult(p4class);
								textArea.append(nick+"의 순서는 "+p4tn+"번입니다.\n");
								user.turnresult(p4tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
							}
							else if(p4class == 1) {
								textArea.append(nick+"의 직업은 부관 입니다.\n");
								user.classresult(p4class);
								textArea.append(nick+"의 순서는 "+p4tn+"번입니다.\n");
								user.turnresult(p4tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
							
							}
							else if(p4class == 2) {
								textArea.append(nick+"의 직업은 무법자 입니다.\n");
								user.classresult(p4class);
								textArea.append(nick+"의 순서는 "+p4tn+"번입니다.\n");
								user.turnresult(p4tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
							
							}
							else if(p4class == 3) {
								textArea.append(nick+"의 직업은 배신자 입니다.\n");
								user.classresult(p4class);
								textArea.append(nick+"의 순서는 "+p4tn+"번입니다.\n");
								user.turnresult(p4tn);
								user.playerfirsthand(p1hp, p2hp, p3hp, p4hp);
								
								
							}
							else {
								textArea.append("에러!");
								
							}
							if(p4character == 0) {
								textArea.append(nick+"의 캐릭터는 윌리 더 키드입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p4hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p4character == 1) {
								textArea.append(nick+"의 캐릭터는 캘러미티 자넷입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p4hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p4character == 2) {
								textArea.append(nick+"의 캐릭터는 폴 리그레트입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p4hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p4character == 3) {
								textArea.append(nick+"의 캐릭터는 로즈 뮬란입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p4hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p4character == 4) {
								textArea.append(nick+"의 캐릭터는 슬랩 더 킬러입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p4hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p4character == 5) {
								textArea.append(nick+"의 캐릭터는 수지 라파에트입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p4hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p4character == 6) {
								textArea.append(nick+"의 캐릭터는 바트 캐시디입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p4hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							else if(p4character == 7) {
								textArea.append(nick+"의 캐릭터는 시드케첨입니다.\n");
								user.characterresult(p1character,p2character,p3character,p4character);
								textArea.append(nick+"의 체력 : "+p4hp);
								user.hpresult(p1hp,p2hp,p3hp,p4hp);
							}
							
							else {
								textArea.append("에러!");
								
							}
							textArea.append("인원이 가득 찼습니다..\n");
							textArea.append("게임을 시작하겠습니다...\n");
							user.gameprogress(first,second,third,fourth,
									p1hp,p2hp,p3hp,p4hp,
									p1tn,p2tn,p3tn,p4tn,
									p111hd,p222hd,p333hd,p444hd,p1class,p2class,p3class,p4class);
							break;
						}
						
							
							
						
					}
						
					
				catch (IOException e) {
						textArea.append("!!!! accept서버접속... !!!!\n");
					} 
					
				}
				
				

			}
		});

		th.start();

	}

	class UserInfo extends Thread {

		private InputStream is;
		private OutputStream os;
		private DataInputStream dis;
		private DataOutputStream dos;

		private Socket user_socket;
		private Vector user_vc;

		private String Nickname = "";
		
		public String Select = "";
		public UserInfo(Socket soc, Vector vc) 
		{
			
			this.user_socket = soc;
			this.user_vc = vc;

			User_network();
			
		
			
			

		}
		

		public void User_network() {
			
			
			try {
				
			
				is = user_socket.getInputStream();
				dis = new DataInputStream(is);
				os = user_socket.getOutputStream();
				dos = new DataOutputStream(os);
				
				Server s = new Server();
				
				
				Nickname = dis.readUTF();
				textArea.append(" ID " +Nickname+"\n");
				
				textArea.setForeground(Color.black);
				
				
				

			} catch (Exception e) {
				textArea.append("텍스트에어리어1\n");
			}
			
		}
		
		public void classresult(int b) {
			 int i = Integer.parseInt(Nickname) ;
			if(i==1) {
				if(b==0) {
					send_Message(Nickname+"번 플레이어 직업 보안관");
				}
				else if(b==1) {
					send_Message(Nickname+"번 플레이어 직업 부관");
				}
				else if(b==2) {
					send_Message(Nickname+"번 플레이어 직업 무법자");
				}
				else if(b==3) {
					send_Message(Nickname+"번 플레이어 직업 배신자");
				}
				else {
					textArea.append("에러!");
					
				}
			}
			else if(i==2) {
				if(b==0) {
					send_Message(Nickname+"번 플레이어 직업 보안관");
				}
				else if(b==1) {
					send_Message(Nickname+"번 플레이어 직업 부관");
				}
				else if(b==2) {
					send_Message(Nickname+"번 플레이어 직업 무법자");
				}
				else if(b==3) {
					send_Message(Nickname+"번 플레이어 직업 배신자");
				}
				else {
					textArea.append("에러!");
					
				}
				
			}
			else if(i==3) {
				if(b==0) {
					send_Message(Nickname+"번 플레이어 직업 보안관");
				}
				else if(b==1) {
					send_Message(Nickname+"번 플레이어 직업 부관");
				}
				else if(b==2) {
					send_Message(Nickname+"번 플레이어 직업 무법자");
				}
				else if(b==3) {
					send_Message(Nickname+"번 플레이어 직업 배신자");
				}
				else {
					textArea.append("에러!");
					
				}
			}
			else if(i==4) {
				if(b==0) {
					send_Message(Nickname+"번 플레이어 직업 보안관");
				}
				else if(b==1) {
					send_Message(Nickname+"번 플레이어 직업 부관");
				}
				else if(b==2) {
					send_Message(Nickname+"번 플레이어 직업 무법자");
				}
				else if(b==3) {
					send_Message(Nickname+"번 플레이어 직업 배신자");
				}
				else {
					textArea.append("에러!");
					
				}
			}
			else {
				textArea.append("에러!");
				
			}
			
		}
		
		public void characterresult(int b,int c,int d,int e) {
			 int i = Integer.parseInt(Nickname) ;
				
					if(b==0) {
						send_Message("p1 캐릭터 : 윌리 더 키드");
					}
					else if(b==1) {
						send_Message("p1 캐릭터 : 캘러미티 자넷");
					}
					else if(b==2) {
						send_Message("p1 캐릭터 : 폴 리그레트");
					}
					else if(b==3) {
						send_Message("p1 캐릭터 : 로즈 뮬란");
					}
					else if(b==4) {
						send_Message("p1 캐릭터 : 슬랩 더 킬러");
					}
					else if(b==5) {
						send_Message("p1 캐릭터 : 수지 라파에트");
					}
					else if(b==6) {
						send_Message("p1 캐릭터 : 바트 캐시디");
					}
					else if(b==7) {
						send_Message("p1 캐릭터 : 시드케첨");
					}
					else {
						textArea.append("에러!");
						
					}
				
			
					if(c==0) {
						send_Message("p2 캐릭터 : 윌리 더 키드");
					}
					else if(c==1) {
						send_Message("p2 캐릭터 : 캘러미티 자넷");
					}
					else if(c==2) {
						send_Message("p2 캐릭터 : 폴 리그레트");
					}
					else if(c==3) {
						send_Message("p2 캐릭터 : 로즈 뮬란");
					}
					else if(c==4) {
						send_Message("p2 캐릭터 : 슬랩 더 킬러");
					}
					else if(c==5) {
						send_Message("p2 캐릭터 : 수지 라파에트");
					}
					else if(c==6) {
						send_Message("p2 캐릭터 : 바트 캐시디");
					}
					else if(c==7) {
						send_Message("p2 캐릭터 : 시드케첨");
					}
					else {
						textArea.append("에러!");
						
					}
					
				
				
					if(d==0) {
						send_Message("p3 캐릭터 : 윌리 더 키드");
					}
					else if(d==1) {
						send_Message("p3 캐릭터 : 캘러미티 자넷");
					}
					else if(d==2) {
						send_Message("p3 캐릭터 : 폴 리그레트");
					}
					else if(d==3) {
						send_Message("p3 캐릭터 : 로즈 뮬란");
					}
					else if(d==4) {
						send_Message("p3 캐릭터 : 슬랩 더 킬러");
					}
					else if(d==5) {
						send_Message("p3 캐릭터 : 수지 라파에트");
					}
					else if(d==6) {
						send_Message("p3 캐릭터 : 바트 캐시디");
					}
					else if(d==7) {
						send_Message("p3 캐릭터 : 시드케첨");
					}
					else {
						textArea.append("에러!");
						
					}
				
				
					if(e==0) {
						send_Message("p4 캐릭터 : 윌리 더 키드");
					}
					else if(e==1) {
						send_Message("p4 캐릭터 : 캘러미티 자넷");
					}
					else if(e==2) {
						send_Message("p4 캐릭터 : 폴 리그레트");
					}
					else if(e==3) {
						send_Message("p4 캐릭터 : 로즈 뮬란");
					}
					else if(e==4) {
						send_Message("p4 캐릭터 : 슬랩 더 킬러");
					}
					else if(e==5) {
						send_Message("p4 캐릭터 : 수지 라파에트");
					}
					else if(e==6) {
						send_Message("p4 캐릭터 : 바트 캐시디");
					}
					else if(e==7) {
						send_Message("p4 캐릭터 : 시드케첨");
					}
					else {
						textArea.append("에러!");
						
					}
				
		}
		
		
		public void hpresult(int hp1,int hp2, int hp3, int hp4) {
			 int i = Integer.parseInt(Nickname) ;
			
			
				send_Message("p1hp : "+hp1);
				send_Message("p2hp : "+hp2);
				send_Message("p3hp : "+hp3);
				send_Message("p4hp : "+hp4);
				
				
			
		}
		
		int p1bang = 0,p2bang = 0,p3bang = 0,p4bang = 0;
		int p1exit = 0,p2exit = 0,p3exit = 0,p4exit = 0;
		int p1bangdraw,p2bangdraw ,p3bangdraw,p4bangdraw;
		int p1exitdraw ,p2exitdraw,p3exitdraw ,p4exitdraw;
		
		
		public void playerfirsthand(int p1hp, int p2hp, int p3hp, int p4hp) {
			
		
			
			int result=0;
			
			do {
				p1bang = (int)(Math.random()*5+1);
				p1exit = (int)(Math.random()*5+1);
			}
			while((p1bang + p1exit)!=p1hp);
		
		
			
				handresult(p1bang, p1exit,1);
				

				do {
					p2bang = (int)(Math.random()*5+1);
					p2exit = (int)(Math.random()*5+1);
				}
				while((p2bang + p2exit)!=p2hp);
			
			
				
					handresult(p2bang, p2exit,2);
					

					do {
						p3bang = (int)(Math.random()*5+1);
						p3exit = (int)(Math.random()*5+1);
					}
					while((p3bang + p3exit)!=p3hp);
				
				
					
						handresult(p3bang, p3exit,3);
						
					

						do {
							p4bang = (int)(Math.random()*5+1);
							p4exit = (int)(Math.random()*5+1);
						}
						while((p4bang + p4exit)!=p4hp);
					
					
						
							handresult(p4bang, p4exit,4);
		
				
			
		
			
		}
		
		public void turnresult(int b) {
			 int i = Integer.parseInt(Nickname) ;
			if(i==1) {
			
				send_Message(Nickname+"번 플레이어 순서: "+b+"번");
				}
				
			
			else if(i==2) {
				
				send_Message(Nickname+"번 플레이어 순서: "+b+"번");
			}
				
				
			
			else if(i==3) {
				
				send_Message(Nickname+"번 플레이어 순서: "+b+"번");
				
			}
			else if(i==4) {
				
				send_Message(Nickname+"번 플레이어 순서: "+b+"번");
				
			}
			else {
				textArea.append("에러!");
				
			}
			
		}
		
		public void handresult(int a, int b, int c) {
			 int i = Integer.parseInt(Nickname) ;
				if(i==1 && c == 1) {
				
					send_Message(Nickname+"번 플레이어 뱅: "+a);
					send_Message(Nickname+"번 플레이어 빗나감: "+b);
					
					}
					
				
				else if(i==2 && c == 2) {
					
					send_Message(Nickname+"번 플레이어 뱅: "+a);
					send_Message(Nickname+"번 플레이어 빗나감: "+b);
				}
					
					
				
				else if(i==3 && c == 3) {
					
					send_Message(Nickname+"번 플레이어 뱅: "+a);
					send_Message(Nickname+"번 플레이어 빗나감: "+b);
					
				}
				else if(i==4 && c == 4) {
					
					send_Message(Nickname+"번 플레이어 뱅: "+a);
					send_Message(Nickname+"번 플레이어 빗나감: "+b);
					
				}
				else {
					textArea.append("에러!");
					
				}
		}
		
		int p1class,p2class,p3class,p4class;
		
		public void gameprogress(String p1,String p2, String p3, String p4, int p1hp, int p2hp, int p3hp, int p4hp, int p1tn, int p2tn, int p3tn, int p4tn, int p1hd, int p2hd, int p3hd, int p4hd,int p1classr,int p2classr, int p3classr, int p4classr) {
				int i = Integer.parseInt(Nickname) ;
			 	Duel c = new Duel(p1hp,p2hp,p3hp,p4hp);
			 	
				int a = 0;
				String first=p1,second=p2,third=p3,fourth=p4;
				String p1dead;
				String p2dead;
				String p3dead;
				String p4dead;
				Turnchoice tc = new Turnchoice(p1tn,p2tn,p3tn,p4tn);
				Hand hd = new Hand();
				int gameover;
				p1dead= c.p1dead();
				p2dead = c.p2dead();
				p3dead = c.p3dead();
				p4dead= c.p4dead();
				
				
				
				gameover = c.gameresult(p1dead,p2dead,p3dead,p4dead);
				Aliveordead ad = new Aliveordead(first, second, third, fourth);
				int ad1 = ad.Aliveordead1(p1dead, p2dead, p3dead, p4dead);
				
					
				p1class= p1classr;
				p2class= p2classr;
				p3class= p3classr;
				p4class= p4classr;
				
				
				firstturn(first, second, third, fourth,p1tn,p2tn,p3tn,p4tn,p1hd,p2hd,p3hd,p4hd,p1hp,p2hp,p3hp,p4hp);
			
			
				
		
		}
	
		
		
		
		
		

		public void InMessage(String str) {
			
			
			
			textArea.append(Nickname+":" + str+"\n");
			
			broad_cast(str);

		}

		public void broad_cast(String str) {
			for (int i = 0; i < user_vc.size(); i++) {
				UserInfo imsi = (UserInfo) user_vc.elementAt(i);
				
				imsi.send_Message(Nickname+" : "+str);

			}

		}

		public void send_Message(String str) {
			try 
			{ 	
				
					dos.writeUTF(str);
				
				
			
				
			} 
			catch (IOException e) {
				textArea.append("텍스트에어리어2\n");	
			}
		}
	
		public void run() 
		{
			

			while (true) {
				try {
					
					
					String msg = dis.readUTF();
					
						
				
						if(msg.equals("1")) {
							firstround(msg);
						}
						else if(msg.equals("2")) {
							firstround(msg);
						
						}
						
						else if(msg.equals("3")) {
							secondround(msg);
						}
						else if(msg.equals("4")) {
							secondround(msg);
						
						}
						else if(msg.equals("5")) {
							thirdround(msg);
						
						}
						else if(msg.equals("6")) {
							thirdround(msg);
						
						}
						else if(msg.equals("7")) {
							fourthround(msg);
						
						}
						else if(msg.equals("8")) {
							fourthround(msg);
						
						}
						else if(msg.equals("11")) {
							 broad_cast("뱅!");
							p1pick(msg);
							handreduce(msg);
							
						
						}
						else if(msg.equals("12")) {
							 broad_cast("빗나감!");
							p1pick(msg);
							handreduce(msg);
						
						}
						else if(msg.equals("13")) {
							firstreaction(msg);
						
						}
						else if(msg.equals("14")) {
							
							firstreaction(msg);
						
						}
						else if(msg.equals("21")) {
							 broad_cast("뱅!");
							 p2pick(msg);
							 handreduce(msg);
						}
						else if(msg.equals("22")) {
							 broad_cast("빗나감!");
							 p2pick(msg);
							 handreduce(msg);
						}
						else if(msg.equals("23")) {
							secondreaction(msg);
							
						}
						else if(msg.equals("24")) {
							secondreaction(msg);
							
						}
						else if(msg.equals("31")) {
							 broad_cast("뱅!");
							 p3pick(msg);
							 handreduce(msg);
						}
						else if(msg.equals("32")) {
							 broad_cast("빗나감!");
							 p3pick(msg);
							 handreduce(msg);
						}
						else if(msg.equals("33")) {
							thirdreaction(msg);
							
						}
						else if(msg.equals("34")) {
							thirdreaction(msg);
							
						}
						else if(msg.equals("41")) {
							 broad_cast("뱅!");
							 p4pick(msg);
							 handreduce(msg);
						}
						else if(msg.equals("42")) {
							 broad_cast("빗나감!");
							 p4pick(msg);
							 handreduce(msg);
						}
						else if(msg.equals("43")) {
							fourthreaction(msg);
							
						}
						else if(msg.equals("44")) {
							fourthreaction(msg);
							
						}
						
						InMessage(msg);
					
					
				} 
				catch (IOException e) 
				{
					
					try {
						dos.close();
						dis.close();
						user_socket.close();
						vc.removeElement( this ); 
						textArea.append(Nickname +" :퇴장하였습니다. \n");
						//textArea.append("하2\n");
						break;
					
					} catch (Exception ee) {
					
					}
				}

			}
			
			
			
		}
		
		
		
		String first,second,third,fourth;
		int p1hp,p2hp,p3hp,p4hp;
		int p1tn,p2tn,p3tn,p4tn;
		int p1hd,p2hd,p3hd,p4hd;
		int p1pick, p2pick, p3pick, p4pick;
		
		
		
		
		public void p1pick(String a) {
			p1pick = Integer.parseInt(a);
			p1pick = p1pick%10;
		}
		
		public void p2pick(String a) {
			p2pick = Integer.parseInt(a);
			p2pick = p2pick%10;
		}
		
		public void p3pick(String a) {
			p3pick = Integer.parseInt(a);
			p3pick = p3pick%10;
		}
		
		public void p4pick(String a) {
			p4pick = Integer.parseInt(a);
			p4pick = p4pick%10;
		}
		
		public void playerhp(int a,String b) {
			int i = Integer.parseInt(Nickname) ;
			
			if(i<5) {
				if(b.equals("p1")) {
					p1hp = p1hp - a;
				}
				else if(b.equals("p2")) {
					p2hp = p2hp - a;
				}
				else if(b.equals("p3")) {
					p3hp = p3hp - a;
				}
				else if(b.equals("p4")) {
					p4hp = p4hp - a;
				}
			}
			
			
		}
		int firstdead=0,seconddead=0,thirddead=0,fourthdead=0;
		int p1dead=0,p2dead=0,p3dead=0,p4dead=0;
		int c1dead=0,c2dead=0,c3dead=0,c4dead=0;
		
		public int peopledead1() {
			
			if(first.equals("p1") && p1hp == 0) {
				firstdead = 1;
				p1dead = 1;
				classdead();
				return 1;
			}
			else if(first.equals("p2") && p2hp == 0) {
				firstdead = 1;
				p2dead = 1;
				classdead();
				return 1;
			}
			else if(first.equals("p3") && p3hp == 0) {
				firstdead = 1;
				p3dead = 1;
				classdead();
				return 1;
			}
			else if(first.equals("p4") && p4hp == 0) {
				firstdead = 1;
				p4dead = 1;
				classdead();
				return 1;
			}
			else {
				classdead();
				return 0;
				
			}
		
			
		
		}
		
		public int peopledead2() {
		
			if(second.equals("p1") && p1hp == 0) {
				seconddead = 1;
				p1dead = 1;
				classdead();
				return 1;
			}
			else if(second.equals("p2") && p2hp == 0) {
				seconddead = 1;
				p2dead = 1;
				classdead();
				return 1;
			}
			else if(second.equals("p3") && p3hp == 0) {
				seconddead = 1;
				p3dead = 1;
				classdead();
				return 1;
			}
			else if(second.equals("p4") && p4hp == 0) {
				seconddead = 1;
				p4dead = 1;
				classdead();
				return 1;
			}
			else {
				classdead();
				return 0;
			}
			
			
		}
		
		public int peopledead3() {
			
			
			
			if(third.equals("p1") && p1hp == 0) {
				thirddead = 1;
				p1dead = 1;
				classdead();
				return 1;
			}
			else if(third.equals("p2") && p2hp == 0) {
				thirddead = 1;
				p2dead = 1;
				classdead();
				return 1;
			}
			else if(third.equals("p3") && p3hp == 0) {
				thirddead = 1;
				p3dead = 1;
				classdead();
				return 1;
			}
			else if(third.equals("p4") && p4hp == 0) {
				thirddead = 1;
				p4dead = 1;
				classdead();
				return 1;
			}
			else {
				classdead();
				return 0;
			}
			
			
		}

		public int peopledead4() {

				if(fourth.equals("p1") && p1hp == 0) {
					fourthdead = 1;
					p1dead = 1;
					classdead();
					return 1;
				}
				else if(fourth.equals("p2") && p2hp == 0) {
					fourthdead = 1;
					p2dead = 1;
					classdead();
					return 1;
				}
				else if(fourth.equals("p3") && p3hp == 0) {
					fourthdead = 1;
					p3dead = 1;
					classdead();
					return 1;
				}
				else if(fourth.equals("p4") && p4hp == 0) {
					fourthdead = 1;
					p4dead = 1;
					classdead();
					return 1;
				}
				else {
					classdead();
					return 0;
				}
				
		}
		
		
		public void classdead() {
			if(p1class == 0 && p1dead == 1) {
				c1dead = 1;
			}
			else if(p1class==1 && p1dead == 1) {
				c2dead = 1;
			}
			else if(p1class==2 && p1dead == 1) {
				c3dead = 1;
			}
			else if(p1class==3 && p1dead == 1) {
				c4dead = 1;
			}
			
			
			if(p2class == 0 && p2dead == 1) {
				c1dead = 1;
			}
			else if(p2class==1 && p2dead == 1) {
				c2dead = 1;
			}
			else if(p2class==2 && p2dead == 1) {
				c3dead = 1;
			}
			else if(p2class==3 && p2dead == 1) {
				c4dead = 1;
			}
			
			if(p3class == 0 && p3dead == 1) {
				c1dead = 1;
			}
			else if(p3class==1 && p3dead == 1) {
				c2dead = 1;
			}
			else if(p3class==2 && p3dead == 1) {
				c3dead = 1;
			}
			else if(p3class==3 && p3dead == 1) {
				c4dead = 1;
			}
			
			if(p4class == 0 && p4dead == 1) {
				c1dead = 1;
			}
			else if(p4class==1 && p4dead == 1) {
				c2dead = 1;
			}
			else if(p4class==2 && p4dead == 1) {
				c3dead = 1;
			}
			else if(p4class==3 && p4dead == 1) {
				c4dead = 1;
			}
			
		}
		
		public int gameover() {
			if(c1dead == 1 && c3dead == 0) {
				broad_cast("무법자가 승리하였습니다.");
				return 1;
			}
			else if(c4dead==0 && c1dead==1 && c2dead==1 && c3dead==1) {
				broad_cast("배신자가 승리하였습니다.");
				return 1;
			}
			else if(c1dead == 0 && c3dead == 1 & c4dead == 1) {
				broad_cast("보안관과 부관이 승리하였습니다.");
				return 1;
			}
			else {
				return 0;
			}
			
		}
		
		public void draw(String a) {
			 int i = Integer.parseInt(Nickname) ;
			 int k;
			 
			 
			 
			if(i==1 && a.equals("p1")) {
				broad_cast("드로우!");
				k = (int)(Math.random()*2+1);
				if(k==1) {
					p1bang = p1bang + 1;
				}else if(k==2) {
					p1exit = p1exit + 1;
				}
			}
			else if(i==2 && a.equals("p2")) {
				broad_cast("드로우!");
				k = (int)(Math.random()*2+1);
				if(k==1) {
					p2bang = p2bang + 1;
				}else if(k==2) {
					p2exit = p2exit + 1;
				}
			}
			
			else if(i==3 && a.equals("p3")) {
				broad_cast("드로우!");
				k = (int)(Math.random()*2+1);
				if(k==1) {
					p3bang = p3bang + 1;
				}else if(k==2) {
					p3exit = p3exit + 1;
				}
			}
			if(i==4 && a.equals("p4")) {
				broad_cast("드로우!");
				k = (int)(Math.random()*2+1);
				if(k==1) {
					p4bang = p4bang + 1;
				}else if(k==2) {
					p4exit = p4exit + 1;
				}
			}
			
		}
		
		public void playerhandshow(String a) {
			 int i = Integer.parseInt(Nickname) ;
			if(i==1 && a.equals("p1")) {
				broad_cast("p1 플레이어 뱅: "+p1bang);
				broad_cast("p1 플레이어 빗나감: "+p1exit);
			}
			else if(i==2 && a.equals("p2")) {
				broad_cast("p2 플레이어 뱅: "+p2bang);
				broad_cast("p2 플레이어 빗나감: "+p2exit);
			}
			
			else if(i==3 && a.equals("p3")) {
				broad_cast("p3 플레이어 뱅: "+p3bang);
				broad_cast("p3 플레이어 빗나감: "+p3exit);
			}
			else if(i==4 && a.equals("p4")) {
				broad_cast("p4 플레이어 뱅: "+p4bang);
				broad_cast("p4 플레이어 빗나감: "+p4exit);
			}
		}
		
		public void handreduce(String a) {
			 int i = Integer.parseInt(Nickname) ;
				if(i==1 && a.equals("11")) {

					p1bang = p1bang -1;
					
				}
				
				else if(i==1 && a.equals("12")) {

					p1exit = p1exit -1;
					
				}
				
				 if(i==2 && a.equals("21")) {

					p2bang = p2bang -1;
				}
				
				else if(i==2 && a.equals("22")) {

					p2exit = p2exit -1;
				}
				
				 if(i==3 && a.equals("31")) {

					p3bang = p3bang -1;
				}
				
				else if(i==3 && a.equals("32")) {

					p3exit = p3exit -1;
				}
				
				 if(i==4 && a.equals("41")) {

					p4bang = p4bang -1;
				}
				
				else if(i==4 && a.equals("42")) {

					p4exit = p4exit -1;
				}
				
				
		}
		
		public void playerhandcheck(String a) {
			 int i = Integer.parseInt(Nickname) ;
			 int k;
			 
			 
			 
			if(i==1 && a.equals("p1")) {
				
				do {
					k = (int)(Math.random()*2+1);
					if(k==1) {
						p1bang = p1bang - 1;
					}else if(k==2) {
						p1exit = p1exit - 1;
					}
				}while((p1bang+p1exit)>p1hp);

			}
			
			if(i==2 && a.equals("p2")) {
				
				do {
					k = (int)(Math.random()*2+1);
					if(k==1) {
						p2bang = p2bang - 1;
					}else if(k==2) {
						p2exit = p2exit - 1;
					}
				}while((p2bang+p2exit)>p2hp);

			}
			
			if(i==3 && a.equals("p3")) {
				
				do {
					k = (int)(Math.random()*2+1);
					if(k==1) {
						p3bang = p3bang - 1;
					}else if(k==2) {
						p3exit = p3exit - 1;
					}
				}while((p3bang+p3exit)>p3hp);

			}
			
			if(i==4 && a.equals("p4")) {
				
				do {
					k = (int)(Math.random()*2+1);
					if(k==1) {
						p4bang = p4bang - 1;
					}else if(k==2) {
						p4exit = p4exit - 1;
					}
				}while((p4bang+p4exit)>p4hp);

			}
			
		
			
		}
		
		
		public void firstturn(String firstr, String secondr, String thirdr, String fourthr,int p1tnr,int p2tnr, int p3tnr, int p4tnr, int p1hdr, int p2hdr, int p3hdr, int p4hdr, int p1hpr, int p2hpr, int p3hpr, int p4hpr ) {
			 int i = Integer.parseInt(Nickname) ;
			first = firstr;
			second = secondr;
			third = thirdr;
			fourth = fourthr;
			p1tn = p1tnr;
			p2tn = p2tnr;
			p3tn = p3tnr;
			p4tn = p4tnr;
			p1hd = p1hdr;
			p2hd = p2hdr;
			p3hd = p3hdr;
			p4hd = p4hdr;
			p1hp = p1hpr;
			p2hp = p2hpr;
			p3hp = p3hpr;
			p4hp = p4hpr;
			
			
			p1pick=0;
			p2pick=0;
			p3pick=0;
			p4pick=0;
			if(peopledead1()==1) {
				send_Message("첫번째 차례인"+first+"는 사망했습니다.");
				secondturn();
			}else {
				
				send_Message("첫번째 차례인"+first+"의 차례입니다.");
				draw(first);
				playerhandshow(first);
				send_Message("행동을 선택하십시오 카드선택 1 넘어가기 2");
			}
			
				
				
			 
			
		
	
			
		}
		
		public void firstround(String a) {
			 int i = Integer.parseInt(Nickname) ;
				

		
				
			 if(a.equals("1")) {
				
				
				 firstduel();
				 
				 
				 
			 }
				
			 else if(a.equals("2")) {
					
					
				
					
					secondturn();

				}
		}
		public void firstduel() {
			
			 
			 
			 broad_cast("카드를 고르시오");
				broad_cast("카드의 대상을 고르시오");
				broad_cast(second+"(13)"+"  :  "+fourth+"(14)");
			
			
			
			
		}
		
		public void firstreaction (String a){
				
				if(a.equals("13")) {
					broad_cast(second+"님 지목되셨습니다. 카드를 고르세요");
				
					Timer t = new Timer();
					TimerTask tt = new TimerTask() {
					
					@Override
					public void run() {
						broad_cast("시간이 다 됐습니다.");
						firstreactionresult(second);
					}
					
				};
				t.schedule(tt, 5000);
					
					
		
				}
				else if(a.equals("14")) {
					broad_cast(fourth+"님 지목되셨습니다. 카드를 고르세요");
					

					Timer t = new Timer();
					TimerTask tt = new TimerTask() {
					
					@Override
					public void run() {
						broad_cast("시간이 다 됐습니다.");
						firstreactionresult(fourth);
					}
					
				};
				t.schedule(tt, 5000);
				
				}
			
				
				
				
		}
		
		
		
		
		public void firstreactionresult(String a) {
			
			
			int result;
			int attack = 0;
			int defense = 0;
			int damage;
			String defender = a;
			if(first.equals("p1")) {
				attack = p1pick;
			}
			else if(first.equals("p2")) {
				attack = p2pick;
			}
			else if(first.equals("p3")) {
				attack = p3pick;
			}
			else if(first.equals("p4")) {
				attack = p4pick;
			}
			else {
				
			}
			
			if(a.equals("p1")) {
				defense = p1pick;
				
			}
			else if(a.equals("p2")) {
				defense = p2pick;
				
			}
			else if(a.equals("p3")) {
				defense = p3pick;
				
			}
			else if(a.equals("p4")) {
				defense = p4pick;
				
			}
			else {
				
			}
			
			
			result = attack - defense;
			

			
				if(result<0) {
					broad_cast("막았습니다.");
					//playerhandcheck(first);
					//playerhandshow(first);
					secondturn();
					
				}
				else {
				
					broad_cast("못 막았습니다.");
					broad_cast(defender);
					
					
					damage=1;
					playerhp(damage,defender);
					//playerhandcheck(first);
					//playerhandshow(first);
					secondturn();
				
					
				}
				
				
			
	}
		
		
		
		
		public void secondturn() {
			 int i = Integer.parseInt(Nickname) ;
				p1pick=0;
				p2pick=0;
				p3pick=0;
				p4pick=0;
			
			
			
			peopledead2();
			gameover();
			if(gameover() == 1) {
				broad_cast("게임이 끝났습니다.");
			}
			else {
				
			
			
			if(peopledead2()==1) {
				
			}else {
				broad_cast("----hp현황----");
				broad_cast("p1hp : "+p1hp);
				broad_cast("p2hp : "+p2hp);
				broad_cast("p3hp : "+p3hp);
				broad_cast("p4hp : "+p4hp);
				if(peopledead1()==1) {
					broad_cast("두번째 차례인"+second+"는 사망하였습니다.");
					thirdturn();
				}else {
					
					broad_cast("첫번째 차례"+first+"의 차례가 끝났습니다.");
					broad_cast("두번째 차례인"+second+"의 차례입니다.");
					draw(second);
					//playerhandshow(second);
					broad_cast("행동을 선택하십시오 카드선택 3 넘어가기 4");
				}
				
			}
			}
			
			
			
			
		
			
			
			
			secondround("선택하시오");		
		}
		
		
		public void secondround(String a) {
			 int i = Integer.parseInt(Nickname) ;
			 


				if(a.equals("3")) {
					secondduel();
					
				}
				else if(a.equals("4")) {
					

					thirdturn( );
				
				}
		}
		
		
		public void secondduel() {
			
			 
			 
			 broad_cast("카드를 고르시오");
				broad_cast("카드를 대상을 고르시오");
				broad_cast(first+"(23)"+"  :  "+third+"(24)");
			
			
			
			
		}
		
		public void secondreaction (String a){
			
				if(a.equals("23")) {
					broad_cast(first+"님 지목되셨습니다. 카드를 고르세요");
				
					Timer t = new Timer();
					TimerTask tt = new TimerTask() {
					
					@Override
					public void run() {
						broad_cast("시간이 다 됐습니다.");
						secondreactionresult(first);
					}
					
				};
				t.schedule(tt, 5000);
					
					
		
				}
				else if(a.equals("24")) {
					broad_cast(third+"님 지목되셨습니다. 카드를 고르세요");
					

					Timer t = new Timer();
					TimerTask tt = new TimerTask() {
					
					@Override
					public void run() {
						broad_cast("시간이 다 됐습니다.");
						secondreactionresult(third);
					}
					
				};
				t.schedule(tt, 5000);
				
				}
			
				
				
				
		}
		
		
		
		
		public void secondreactionresult(String a) {
			
			
			int result;
			int attack = 0;
			int defense = 0;
			int damage;
			String defender = null;
			if(second.equals("p1")) {
				attack = p1pick;
			}
			else if(second.equals("p2")) {
				attack = p2pick;
			}
			else if(second.equals("p3")) {
				attack = p3pick;
			}
			else if(second.equals("p4")) {
				attack = p4pick;
			}
			if(a.equals("p1")) {
				defense = p1pick;
				
			}
			else if(a.equals("p2")) {
				defense = p2pick;
				
			}
			else if(a.equals("p3")) {
				defense = p3pick;
			
			}
			else if(a.equals("p4")) {
				defense = p4pick;
				
			}
			
			
			result = attack - defense;
			

			
				if(result<0) {
					broad_cast("막았습니다.");
					//playerhandcheck(second);
					//playerhandshow(second);
					thirdturn();
					
				
				}
				else {
			
					broad_cast("못 막았습니다.");
				
					
					damage=1;
					playerhp(damage,a);
				//	playerhandcheck(second);
					//playerhandshow(second);
					thirdturn();
				
				}
	
			
	}
		
		
		

		
		public void thirdturn() {
			 int i = Integer.parseInt(Nickname) ;
			 p1pick=0;
				p2pick=0;
				p3pick=0;
				p4pick=0;
				
				
				peopledead3();
				gameover();
				if(gameover() == 1) {
					broad_cast("게임이 끝났습니다.");
					
				}
				else {
				
					broad_cast("----hp현황----");
					broad_cast("p1hp : "+p1hp);
					broad_cast("p2hp : "+p2hp);
					broad_cast("p3hp : "+p3hp);
					broad_cast("p4hp : "+p4hp);
				if(peopledead3()==1) {
					broad_cast("세번째 차례인"+third+"는 사망하였습니다.");
					fourthturn();
				}else {
					if(peopledead2()==1) {
						broad_cast("세번째 차례인"+third+"의 차례입니다.");
					}
					else {
						broad_cast("두번째 차례"+second+"의 차례가 끝났습니다.");
						broad_cast("세번째 차례인"+third+"의 차례입니다.");
						draw(third);
						//playerhandshow(third);
						broad_cast("행동을 선택하십시오 카드선택 5 넘어가기 6");
					}
					
					
				}
			
			
				}

		

			
			
			thirdround("선택하시오");		
		}
		
		
	
		
		public void thirdround(String a) {
			 int i = Integer.parseInt(Nickname) ;
			 


			 

				if(a.equals("5")) {
					thirdduel();
					
				}
				else if(a.equals("6")) {
					
					fourthturn( );
				
						
						
					
					
				}
		}
		
		
		
		public void thirdduel() {
			
			 
			 
			 broad_cast("카드를 고르시오");
				broad_cast("카드를 대상을 고르시오");
				broad_cast(second+"(33)"+"  :  "+fourth+"(34)");
			
			
			
			
		}
		
		public void thirdreaction (String a){
			
				if(a.equals("33")) {
					broad_cast(second+"님 지목되셨습니다. 카드를 고르세요");
				
					Timer t = new Timer();
					TimerTask tt = new TimerTask() {
					
					@Override
					public void run() {
						broad_cast("시간이 다 됐습니다.");
						thirdreactionresult(second);
					}
					
				};
				t.schedule(tt, 5000);
					
					
		
				}
				else if(a.equals("34")) {
					broad_cast(fourth+"님 지목되셨습니다. 카드를 고르세요");
					

					Timer t = new Timer();
					TimerTask tt = new TimerTask() {
					
					@Override
					public void run() {
						broad_cast("시간이 다 됐습니다.");
						thirdreactionresult(fourth);
					}
					
				};
				t.schedule(tt, 5000);
				
				}
			
				
				
				
		}
		
		
		
		
		public void thirdreactionresult(String a) {
			
			
			int result;
			int attack = 0;
			int defense = 0;
			int damage;
			String defender = null;
			if(third.equals("p1")) {
				attack = p1pick;
			}
			else if(third.equals("p2")) {
				attack = p2pick;
			}
			else if(third.equals("p3")) {
				attack = p3pick;
			}
			else if(third.equals("p4")) {
				attack = p4pick;
			}
			if(a.equals("p1")) {
				defense = p1pick;
				
			}
			else if(a.equals("p2")) {
				defense = p2pick;
				
			}
			else if(a.equals("p3")) {
				defense = p3pick;
			
			}
			else if(a.equals("p4")) {
				defense = p4pick;
				
			}
			
			
			result = attack - defense;
			

			
				if(result<0) {
					broad_cast("막았습니다.");
					//playerhandshow(third);
					//playerhandcheck(third);
					fourthturn();
					
				
				}
				else {
			
					broad_cast("못 막았습니다.");
					
					
					damage=1;
					playerhp(damage,a);
					//playerhandcheck(third);
				//	playerhandshow(third);
					fourthturn();
				
				}
	
			
	}
		
		
		
		
		
		
		

		public void fourthturn() {
			 int i = Integer.parseInt(Nickname) ;
			 p1pick=0;
				p2pick=0;
				p3pick=0;
				p4pick=0;
				
				peopledead4();
				gameover();
				if(gameover() == 1) {
					broad_cast("게임이 끝났습니다.");
				}
				else {
				
					broad_cast("----hp현황----");
					broad_cast("p1hp : "+p1hp);
					broad_cast("p2hp : "+p2hp);
					broad_cast("p3hp : "+p3hp);
					broad_cast("p4hp : "+p4hp);
			 if(peopledead4()==1) {
				 broad_cast("네번째 차례인"+fourth+"는 사망하였습니다.");
				 firstturn2();
			 }else {
				 if(peopledead3()==1) {
					 broad_cast("네번째 차례인"+fourth+"의 차례입니다.");
				 }
				 else {
						broad_cast("세번째 차례"+third+"의 차례가 끝났습니다.");
						broad_cast("네번째 차례인"+fourth+"의 차례입니다.");
						draw(fourth);
						//playerhandshow(fourth);
						broad_cast("행동을 선택하십시오 카드선택 7 넘어가기 8");
				 }
			 }
		
			
			
				}	

		
			fourthround("선택하시오");		
		}
		
		
	
		
		public void fourthround(String a) {
			 int i = Integer.parseInt(Nickname) ;
			
					
					
			 

				if(a.equals("7")) {
					fourthduel();
				}
				else if(a.equals("8")) {
					
					
					firstturn2( );
				
						
					
						
				}
				
				
		}
		
		

		public void fourthduel() {
			
			 
			 
			 broad_cast("카드를 고르시오");
				broad_cast("카드를 대상을 고르시오");
				broad_cast(third+"(43)"+"  :  "+first+"(44)");
			
			
			
			
		}
		
		public void fourthreaction (String a){
			
				if(a.equals("43")) {
					broad_cast(third+"님 지목되셨습니다. 카드를 고르세요");
				
					Timer t = new Timer();
					TimerTask tt = new TimerTask() {
					
					@Override
					public void run() {
						broad_cast("시간이 다 됐습니다.");
						fourthreactionresult(third);
					}
					
				};
				t.schedule(tt, 5000);
					
					
		
				}
				else if(a.equals("44")) {
					broad_cast(first+"님 지목되셨습니다. 카드를 고르세요");
					

					Timer t = new Timer();
					TimerTask tt = new TimerTask() {
					
					@Override
					public void run() {
						broad_cast("시간이 다 됐습니다.");
						fourthreactionresult(first);
					}
					
				};
				t.schedule(tt, 5000);
				
				}
			
				
				
				
		}
		
		
		
		
		public void fourthreactionresult(String a) {
			
			
			int result;
			int attack = 0;
			int defense = 0;
			int damage;
			String defender = null;
			if(fourth.equals("p1")) {
				attack = p1pick;
			}
			else if(fourth.equals("p2")) {
				attack = p2pick;
			}
			else if(fourth.equals("p3")) {
				attack = p3pick;
			}
			else if(fourth.equals("p4")) {
				attack = p4pick;
			}
			if(a.equals("p1")) {
				defense = p1pick;
				
			}
			else if(a.equals("p2")) {
				defense = p2pick;
				
			}
			else if(a.equals("p3")) {
				defense = p3pick;
			
			}
			else if(a.equals("p4")) {
				defense = p4pick;
				
			}
			
			
			result = attack - defense;
			

			
				if(result<0) {
					broad_cast("막았습니다.");
					//playerhandcheck(fourth);
					//playerhandshow(fourth);
					firstturn2();
					
				
				}
				else {
			
					broad_cast("못 막았습니다.");
					
					
					damage=1;
					playerhp(damage,a);
					//playerhandcheck(fourth);
					//playerhandshow(fourth);
					firstturn2();
				}
	
			
	}
		
		
		
		
		
		
		
		public void firstturn2() {
			 int i = Integer.parseInt(Nickname) ;
			 p1pick=0;
				p2pick=0;
				p3pick=0;
				p4pick=0;
			
		

			peopledead1();
			gameover();
			if(gameover() == 1) {
				 broad_cast("게임이 끝났습니다.");
			}
			else {
				broad_cast("----hp현황----");
				broad_cast("p1hp : "+p1hp);
				broad_cast("p2hp : "+p2hp);
				broad_cast("p3hp : "+p3hp);
				broad_cast("p4hp : "+p4hp);
				
			 if(peopledead1()==1) {
				 broad_cast("첫번째 차례인"+first+"는 사망하였습니다.");
				 secondturn();
			 }else {
				 if(peopledead4()==1) {
					 broad_cast("첫번째 차례인"+first+"의 차례입니다.");
				 }
				 else {
					 broad_cast("네번째 차례"+fourth+"의 차례가 끝났습니다.");
					 draw(first);
					// playerhandshow(first);
					 broad_cast("첫번째 차례인"+first+"의 차례입니다.");
						broad_cast("행동을 선택하십시오 카드선택 1 넘어가기 2");
				 }
			 }
			
		
			}
			firstround("선택하시오");	
		}
		
		
	} 
	
	
	


}
