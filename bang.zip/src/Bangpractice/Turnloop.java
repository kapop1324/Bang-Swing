package Bangpractice;

import java.util.Scanner;

public class Turnloop {
	int input;
	public int Turnloop() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("0~9까지의 숫자로 카드를 선택하십시오");
		input = sc.nextInt();
		
			return input;
		
		
	}
	
}
