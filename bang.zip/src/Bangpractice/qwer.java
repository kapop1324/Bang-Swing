package Bangpractice;

public class qwer {
	public void Example(String s) {
		System.out.println(s);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}

}
