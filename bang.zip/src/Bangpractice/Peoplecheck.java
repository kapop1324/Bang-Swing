package Bangpractice;

import java.util.Scanner;

public class Peoplecheck {
	
	Scanner sc = new Scanner(System.in);
	int player_input=0;
	int checksum =0;
	private int baseNumber[] = new int[4];	//정답배열
	private int userNumber[] = new int[4];	
	public synchronized int inputUserNumber1(String in1){ // 사용자값 입력 받아 처리
		
		String in = in1;
		
			userNumber[0]=in.charAt(0)-48;
		
		return userNumber[0];
		
	}
	
	public int Peoplecheck(int a) {
		
		
		System.out.println(a+"명 대기중");
		
		 if(a==4) {
			 
			 
			 return checksum;
			 
		 }
			 
			
		 return 0;		
         
       		
		
	}
}
