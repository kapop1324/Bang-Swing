package Bangpractice;

public class Playercharacter {
	int p1,p2,p3,p4;
	String p1character;
	String p2character;
	String p3character;
	String p4character;
	
	
	public Playercharacter() {
		
		p1 =  (int)(Math.random()*8);
		
		do {
			p2 = (int)(Math.random()*8);
			
			
		} while(p1 == p2);
		
		
		do {
			p3 = (int)(Math.random()*8);
			
		} while(p3 == p1 || p3 == p2);
		
		
		do {
			p4 = (int)(Math.random()*8);
			
			
		} while(p4 == p1 || p4 == p2 || p4==p3);		
		
	}
	
	public int Playercharcter1() {
		if(p1==0) {
			p1character = "윌리 더 키드";
			return 0;
		}
		else if(p1==1) {
			p1character = "캘러미티 자넷";
			return 1;
		}
		else if(p1==2) {
			p1character = "폴 리그레트";
			return 2;
		}
		else if(p1==3) {
			p1character = "로즈 둘란";
			return 3;
		}
		else if(p1==4) {
			p1character = "슬랩 더 킬러";
			return 4;
		}
		else if(p1==5) {
			p1character = "수지 라파에트";
			return 5;
		}
		else if(p1==6) {
			p1character = "바트 캐시디";
			return 6;
		}
		else if(p1==7) {
			p1character = "시드 케첨";
			return 7;
		}
		
		else {
			System.out.println("잘못된 값이 들어왔습니다.");
			return 100;
		}
		
	}
	
	public int Playercharcter2() {
		if(p2==0) {
			p2character = "윌리 더 키드";
			return 0;
		}
		else if(p2==1) {
			p2character = "캘러미티 자넷";
			return 1;
		}
		else if(p2==2) {
			p2character = "폴 리그레트";
			return 2;
		}
		else if(p2==3) {
			p2character = "로즈 둘란";
			return 3;
		}
		else if(p2==4) {
			p2character = "슬랩 더 킬러";
			return 4;
		}
		else if(p2==5) {
			p2character = "수지 라파에트";
			return 5;
		}
		else if(p2==6) {
			p2character = "바트 캐시디";
			return 6;
		}
		else if(p2==7) {
			p2character = "시드 케첨";
			return 7;
		}
		else {
			System.out.println("잘못된 값이 들어왔습니다.");
			return 100;
		}
	}

	public int Playercharcter3() {
		if(p3==0) {
			p3character = "윌리 더 키드";
			return 0;
		}
		else if(p3==1) {
			p3character = "캘러미티 자넷";
			return 1;
		}
		else if(p3==2) {
			p3character = "폴 리그레트";
			return 2;
		}
		else if(p3==3) {
			p3character = "로즈 둘란";
			return 3;
		}
		else if(p3==4) {
			p3character = "슬랩 더 킬러";
			return 4;
		}
		else if(p3==5) {
			p3character = "수지 라파에트";
			return 5;
		}
		else if(p3==6) {
			p3character = "바트 캐시디";
			return 6;
		}
		else if(p3==7) {
			p3character = "시드 케첨";
			return 7;
		}
		
		else {
			System.out.println("잘못된 값이 들어왔습니다.");
			return 100;
		}
		
	}
	public int Playercharcter4() {
		if(p4==0) {
			p4character = "윌리 더 키드";
			return 0;
		}
		else if(p4==1) {
			p4character = "캘러미티 자넷";
			return 1;
		}
		else if(p4==2) {
			p4character = "폴 리그레트";
			return 2;
		}
		else if(p4==3) {
			p4character = "로즈 둘란";
			return 3;
		}
		else if(p4==4) {
			p4character = "슬랩 더 킬러";
			return 4;
		}
		else if(p4==5) {
			p4character = "수지 라파에트";
			return 5;
		}
		else if(p4==6) {
			p4character = "바트 캐시디";
			return 6;
		}
		else if(p4==7) {
			p4character = "시드 케첨";
			return 7;
		}
		else {
			System.out.println("잘못된 값이 들어왔습니다.");
			return 100;
		}
		
	}
	
	
	
	public void Playercharactershow() {
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
}
