package Bangpractice;

public class Turnnumber {
	
	int p1,p2,p3,p4;
	int p1number, p2number, p3number, p4number;
	
	Turnnumber(int a, int b, int c, int d) {
	 	
		p1 = a;
		p2 = b;
		p3 = c;
		p4 = d;
		

		if(p1 == 0) {
			p1number = 1;
			p2number = 2;
			p3number = 3;
			p4number = 4;
			
			
			
		}
		else if(p2 == 0) {
			p1number = 4;
			p2number = 1;
			p3number = 2;
			p4number = 3;
			
			
		}
		else if(p3 == 0) {
			p1number = 3;
			p2number = 4;
			p3number = 1;
			p4number = 2;
			
			
		}
		else if(p4 == 0) {
			p1number = 2;
			p2number = 3;
			p3number = 4;
			p4number = 1;
			
			
		}
		
	}
	
	public int Player1turnnumber() {
		return p1number;
	}
	
	public int Player2turnnumber() {
		return p2number;
	}
	
	public int Player3turnnumber() {
		return p3number;
	}
	
	public int Player4turnnumber() {
		return p4number;
	}
	
	

}
