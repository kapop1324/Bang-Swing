package Bangpractice;

import java.util.Scanner;

public class Peoplechoice {
	
	String first, second, third, fourth;
	
	Peoplechoice(String firstch, String secondch, String thirdch, String fourthch) {
		first = firstch;
		second = secondch;
		third = thirdch;
		fourth = fourthch;
	}

	Scanner sc = new Scanner(System.in);
	

	public String Firstplayerchoice() {
		System.out.println("대상을 선택하십시오");
		System.out.println("1:"+second+" 2:"+fourth+"");
		int input = sc.nextInt();
		if(input == 1) {
			System.out.println(second+"를 선택하셨습니다.");
			return second;
		}
		else {
			System.out.println(fourth+"를 선택하셨습니다.");
			return fourth;
		}
		
	}
	
	public String Secondplayerchoice() {
		System.out.println("대상을 선택하십시오");
		System.out.println("1:"+first+" 2:"+third+"");
		int input = sc.nextInt();
		if(input == 1) {
			System.out.println(first+"를 선택하셨습니다.");
			return first;
		}
		else {
			System.out.println(fourth+"를 선택하셨습니다.");
			return third;
		}
		
	}
	
	public String Thirdplayerchoice() {
		System.out.println("대상을 선택하십시오");
		System.out.println("1:"+second+" 2:"+fourth+"");
		int input = sc.nextInt();
		if(input == 1) {
			System.out.println(second+"를 선택하셨습니다.");
			return second;
		}
		else {
			System.out.println(fourth+"를 선택하셨습니다.");
			return fourth;
		}
	}
	
	public String Fourthplayerchoice() {
		System.out.println("대상을 선택하십시오");
		System.out.println("1:"+first+" 2:"+third+"");
		int input = sc.nextInt();
		if(input == 1) {
			System.out.println(first+"를 선택하셨습니다.");
			return first;
		}
		else {
			System.out.println(third+"를 선택하셨습니다.");
			return third;
		}
	}
	
	
	
}
