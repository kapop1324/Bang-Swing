package Bangpractice;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;




public class MainView extends JFrame {

	private JTextField textField;

	private String id;
	private String ip;
	private int port;
	ImageIcon i = new ImageIcon("./IMGIMG/hi.jpg");
    Image im=i.getImage();
    
    Font F= new Font("Gothic", Font.BOLD, 20);
	
	JButton sendBtn; 
	JTextArea textArea; 
	

	
	
	
	
    

	ImageIcon icon1 = new ImageIcon("./IMGIMG/45.jpg");
	ImageIcon icon2 = new ImageIcon("./IMGIMG/bea.jpg");
	ImageIcon icon3 = new ImageIcon("./IMGIMG/bo.jpg");
	ImageIcon icon4 = new ImageIcon("./IMGIMG/bu.jpg");
	ImageIcon icon5 = new ImageIcon("./IMGIMG/rose.png");
	ImageIcon icon6 = new ImageIcon("./IMGIMG/bat.png");
	ImageIcon icon7 = new ImageIcon("./IMGIMG/suzi.png");
	ImageIcon icon8 = new ImageIcon("./IMGIMG/killer.png");
	ImageIcon icon9 = new ImageIcon("./IMGIMG/sid.png");
	ImageIcon icon10 = new ImageIcon("./IMGIMG/kid.png");
	ImageIcon icon11 = new ImageIcon("./IMGIMG/zanet.png");
	ImageIcon icon12 = new ImageIcon("./IMGIMG/pol.png");
	ImageIcon icon13 = new ImageIcon("./IMGIMG/bang.png");
	ImageIcon icon14 = new ImageIcon("./IMGIMG/miss.png");
	ImageIcon icon15 = new ImageIcon("./IMGIMG/5.png");
	ImageIcon icon16 = new ImageIcon("./IMGIMG/자기체력(5).png");
	ImageIcon icon17 = new ImageIcon("./IMGIMG/자기체력(4).png");
	ImageIcon icon18 = new ImageIcon("./IMGIMG/자기체력(3).png");
	ImageIcon icon19 = new ImageIcon("./IMGIMG/자기체력(2).png");
	ImageIcon icon20 = new ImageIcon("./IMGIMG/자기체력(1).png");
	ImageIcon icon21 = new ImageIcon("./IMGIMG/윗놈체력(5).png");
	ImageIcon icon22 = new ImageIcon("./IMGIMG/윗놈체력(4).png");
	ImageIcon icon23 = new ImageIcon("./IMGIMG/윗놈체력(3).png");
	ImageIcon icon24 = new ImageIcon("./IMGIMG/윗놈체력(2).png");
	ImageIcon icon25 = new ImageIcon("./IMGIMG/윗놈체력(1).png");
	ImageIcon icon26 = new ImageIcon("./IMGIMG/좌우체력(5).png");
	ImageIcon icon27 = new ImageIcon("./IMGIMG/좌우체력(4).png");
	ImageIcon icon28 = new ImageIcon("./IMGIMG/좌우체력(3).png");
	ImageIcon icon29 = new ImageIcon("./IMGIMG/좌우체력(2).png");
	ImageIcon icon30 = new ImageIcon("./IMGIMG/좌우체력(1).png");
	ImageIcon icon31 = new ImageIcon("./IMGIMG/자기체력변경(5).png");
	ImageIcon icon32 = new ImageIcon("./IMGIMG/자기체력변경(4).png");
	ImageIcon icon33 = new ImageIcon("./IMGIMG/자기체력변경(3).png");
	ImageIcon icon34 = new ImageIcon("./IMGIMG/자기체력변경(2).png");
	ImageIcon icon35 = new ImageIcon("./IMGIMG/자기체력변경(1).png");
	ImageIcon icon36 = new ImageIcon("./IMGIMG/윗놈체력변경(5).png");
	ImageIcon icon37 = new ImageIcon("./IMGIMG/윗놈체력변경(4).png");
	ImageIcon icon38 = new ImageIcon("./IMGIMG/윗놈체력변경(3).png");
	ImageIcon icon39 = new ImageIcon("./IMGIMG/윗놈체력변경(2).png");
	ImageIcon icon40 = new ImageIcon("./IMGIMG/윗놈체력변경(1).png");
	ImageIcon icon41 = new ImageIcon("./IMGIMG/좌우체력변경(5).png");
	ImageIcon icon42 = new ImageIcon("./IMGIMG/좌우체력변경(4).png");
	ImageIcon icon43 = new ImageIcon("./IMGIMG/좌우체력변경(3).png");
	ImageIcon icon44 = new ImageIcon("./IMGIMG/좌우체력변경(2).png");
	ImageIcon icon45 = new ImageIcon("./IMGIMG/좌우체력변경(1).png");
	ImageIcon icon46 = new ImageIcon("./IMGIMG/로즈(위).png");
	ImageIcon icon47 = new ImageIcon("./IMGIMG/바트(위).png");
	ImageIcon icon48 = new ImageIcon("./IMGIMG/수지(위).png");
	ImageIcon icon49 = new ImageIcon("./IMGIMG/슬랩(위).png");
	ImageIcon icon50 = new ImageIcon("./IMGIMG/시드(위).png");
	ImageIcon icon51 = new ImageIcon("./IMGIMG/윌리(위).png");
	ImageIcon icon52 = new ImageIcon("./IMGIMG/캘러미티(위).png");
	ImageIcon icon53 = new ImageIcon("./IMGIMG/폴(위).png");
	ImageIcon icon54 = new ImageIcon("./IMGIMG/로즈(왼쪽).png");
	ImageIcon icon55 = new ImageIcon("./IMGIMG/바트(왼쪽).png");
	ImageIcon icon56 = new ImageIcon("./IMGIMG/수지(왼쪽).png");
	ImageIcon icon57 = new ImageIcon("./IMGIMG/슬랩(왼쪽).png");
	ImageIcon icon58 = new ImageIcon("./IMGIMG/시드(왼쪽).png");
	ImageIcon icon59 = new ImageIcon("./IMGIMG/윌리(왼쪽).png");
	ImageIcon icon60 = new ImageIcon("./IMGIMG/캘러미티(왼쪽).png");
	ImageIcon icon61 = new ImageIcon("./IMGIMG/폴(왼쪽).png");
	ImageIcon icon62 = new ImageIcon("./IMGIMG/로즈(오른쪽).png");
	ImageIcon icon63 = new ImageIcon("./IMGIMG/바트(오른쪽).png");
	ImageIcon icon64 = new ImageIcon("./IMGIMG/수지(오른쪽).png");
	ImageIcon icon65 = new ImageIcon("./IMGIMG/슬랩(오른쪽).png");
	ImageIcon icon66 = new ImageIcon("./IMGIMG/시드(오른쪽).png");
	ImageIcon icon67 = new ImageIcon("./IMGIMG/윌리(오른쪽).png");
	ImageIcon icon68 = new ImageIcon("./IMGIMG/캘러미티(오른쪽).png");
	ImageIcon icon69 = new ImageIcon("./IMGIMG/폴(오른쪽).png");
	ImageIcon icon70 = new ImageIcon("./IMGIMG/보안관(왼쪽).png");
	ImageIcon icon71 = new ImageIcon("./IMGIMG/보안관(위).png");
	ImageIcon icon72 = new ImageIcon("./IMGIMG/보안관(오른쪽).png");
	ImageIcon icon73 = new ImageIcon("./IMGIMG/윗놈비밀직업.png");
	ImageIcon icon74 = new ImageIcon("./IMGIMG/좌우비밀직업.png");
	
	JButton btn1 = new JButton(new ImageIcon("./IMGIMG/5.png"));
    JButton btn2 = new JButton(new ImageIcon("./IMGIMG/5.png"));
    JButton btn3 = new JButton();
    JButton btn5 = new JButton();
  
    JButton btn9 = new JButton("bang");
    JButton btn10 = new JButton("miss");
    JButton btn11 = new JButton("선택");
    JButton btn12 = new JButton("좌");
    JButton btn13 = new JButton("turn");
    JButton btn14 = new JButton("우");
    
    JButton btn21 = new JButton(new ImageIcon("./IMGIMG/back2.png"));
    JButton btn22 = new JButton(new ImageIcon("./IMGIMG/back2.png"));
    JButton btn23 = new JButton(new ImageIcon("./IMGIMG/back2.png"));
    JButton btn26 = new JButton(new ImageIcon("./IMGIMG/back2.png"));
    JButton btn27 = new JButton(new ImageIcon("./IMGIMG/back2.png"));
    JButton btn28 = new JButton(new ImageIcon("./IMGIMG/back2.png"));
    
    JButton btn31 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn32 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn33 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn36 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn37 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn38 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    
    JButton btn41 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn42 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn43 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn46 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn47 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    JButton btn48 = new JButton(new ImageIcon("./IMGIMG/back3.png"));
    
    
    JButton btn52 = new JButton();
    JButton btn53 = new JButton();
   
    
    JButton btn58 = new JButton();
    JButton btn59 = new JButton();
   
    
    JButton btn64 = new JButton();
    JButton btn65 = new JButton();
    
    
    
    JButton btn66 = new JButton();
    JButton btn67 = new JButton();
    JButton btn68 = new JButton();
    JButton btn69 = new JButton();
   
	private Socket socket; 
	private InputStream is;
	private OutputStream os;
	private DataInputStream dis;
	private DataOutputStream dos;

	public MainView(String id, String ip, int port)
	{
		this.id = id;
		this.ip = ip;
		this.port = port;

		
		init();
		start();
		
		

		textArea.append("보낸 : " + id + "\n");
		textArea.setFont(F);
		textArea.setForeground(Color.red);
		
		network();

	}

	public void network() {
		
		try {
			socket = new Socket(ip, port);
			if (socket != null) 
			{
				Connection(); 
			}
		} catch (UnknownHostException e) {

		} catch (IOException e) {
			textArea.append("오류검출1번\n");
			
		}

	}
	
	public void kong() {
		String m;
	}
	

	public void Connection() { 

		try { 
			is = socket.getInputStream();
			
			dis = new DataInputStream(is);
			

			
			os = socket.getOutputStream();
			dos = new DataOutputStream(os);
			

		} catch (IOException e) {
			
			textArea.append("오류검출2번\n");
			
		}

		send_Message(id);

		Thread th = new Thread(new Runnable() {
			
					@Override
					public void run() {	
						Myaction5 my5 = new Myaction5();
						while (true) {

							try {
								
								String msg = dis.readUTF();
								textArea.append(msg + "\n");
								//1번플레이어 직업


								
								if(id.equals("1")) {
								
								if(msg.equals("p1hp : 5")) {
									btn66.setIcon(icon31);
								}
								else if(msg.equals("p1hp : 4")) {
									btn66.setIcon(icon32);
								}
								else if(msg.equals("p1hp : 3")) {
									btn66.setIcon(icon33);
								}
								else if(msg.equals("p1hp : 2")) {
									btn66.setIcon(icon34);
								}
								else if(msg.equals("p1hp : 1")) {
									btn66.setIcon(icon35);
								}
								else if(msg.equals("p3hp : 5")) {
									btn67.setIcon(icon36);
									btn53.setIcon(icon71);
								}
								else if(msg.equals("p3hp : 4")) {
									btn67.setIcon(icon37);
								}
								else if(msg.equals("p3hp : 3")) {
									btn67.setIcon(icon38);
								}
								else if(msg.equals("p3hp : 2")) {
									btn67.setIcon(icon39);
								}
								else if(msg.equals("p3hp : 1")) {
									btn67.setIcon(icon40);
								}
								else if(msg.equals("p2hp : 5")) {
									btn68.setIcon(icon41);
								}
								else if(msg.equals("p2hp : 4")) {
									btn68.setIcon(icon42);
								}
								else if(msg.equals("p2hp : 3")) {
									btn68.setIcon(icon43);
								}
								else if(msg.equals("p2hp : 2")) {
									btn68.setIcon(icon44);
								}
								else if(msg.equals("p2hp : 1")) {
									btn68.setIcon(icon45);
								}
								else if(msg.equals("p4hp : 5")) {
									btn69.setIcon(icon41);
								}
								else if(msg.equals("p4hp : 4")) {
									btn69.setIcon(icon42);
								}
								else if(msg.equals("p4hp : 3")) {
									btn69.setIcon(icon43);
								}
								else if(msg.equals("p4hp : 2")) {
									btn69.setIcon(icon44);
								}
								else if(msg.equals("p4hp : 1")) {
									btn69.setIcon(icon45);
								}
								else if(msg.equals("1번 플레이어 직업 무법자")) {
									
									btn3.setIcon(icon1);
								}
								else if(msg.equals("1번 플레이어 직업 배신자")) {
									
									btn3.setIcon(icon2);
								}
								else if(msg.equals("1번 플레이어 직업 보안관")) {
	
									btn3.setIcon(icon3);
								}
								else if(msg.equals("1번 플레이어 직업 부관")) {
									
									btn3.setIcon(icon4);
								}
								else if(msg.equals("p1 캐릭터 : 시드케첨")) {
									
									btn5.setIcon(icon9);
								}
								else if(msg.equals("p1 캐릭터 : 로즈 뮬란")) {
									
									btn5.setIcon(icon5);
									
								}
								else if(msg.equals("p1 캐릭터 : 캘러미티 자넷")) {
									
									btn5.setIcon(icon11);
									
								}
								else if(msg.equals("p1 캐릭터 : 윌리 더 키드")) {
									
									btn5.setIcon(icon10);
								
								}
								else if(msg.equals("p1 캐릭터 : 폴 리그레트")) {
									
									btn5.setIcon(icon12);
									
								}
								else if(msg.equals("p1 캐릭터 : 슬랩 더 킬러")) {
									
									btn5.setIcon(icon8);
									
								}
								else if(msg.equals("p1 캐릭터 : 수지 라파에트")) {
									
									btn5.setIcon(icon7);
									
								}
								else if(msg.equals("p1 캐릭터 : 바트 캐시디")) {
									
									btn5.setIcon(icon6);
									
								}
								else if(msg.equals("p3 캐릭터 : 시드케첨")) {
									
									btn52.setIcon(icon50);
									
								}
								else if(msg.equals("p3 캐릭터 : 로즈 뮬란")) {
									
									btn52.setIcon(icon46);
									
								}
								else if(msg.equals("p3 캐릭터 : 캘러미티 자넷")) {
									
									btn52.setIcon(icon52);
									
								}
								else if(msg.equals("p3 캐릭터 : 윌리 더 키드")) {
									
									btn52.setIcon(icon51);
								
								}
								else if(msg.equals("p3 캐릭터 : 폴 리그레트")) {
									
									btn52.setIcon(icon53);
									
								}
								else if(msg.equals("p3 캐릭터 : 슬랩 더 킬러")) {
									
									btn52.setIcon(icon49);
									
								}
								else if(msg.equals("p3 캐릭터 : 수지 라파에트")) {
									
									btn52.setIcon(icon48);
									
								}
								else if(msg.equals("p3 캐릭터 : 바트 캐시디")) {
									
									btn52.setIcon(icon47);
									
								}
								else if(msg.equals("p2 캐릭터 : 시드케첨")) {
									
									btn59.setIcon(icon58);
									
								}
								else if(msg.equals("p2 캐릭터 : 로즈 뮬란")) {
									
									btn59.setIcon(icon54);
									
								}
								else if(msg.equals("p2 캐릭터 : 캘러미티 자넷")) {
									
									btn59.setIcon(icon60);
									
								}
								else if(msg.equals("p2 캐릭터 : 윌리 더 키드")) {
									
									btn59.setIcon(icon59);
									
								}
								else if(msg.equals("p2 캐릭터 : 폴 리그레트")) {
									
									btn59.setIcon(icon61);
									
								}
								else if(msg.equals("p2 캐릭터 : 슬랩 더 킬러")) {
									
									btn59.setIcon(icon57);
									
								}
								else if(msg.equals("p2 캐릭터 : 수지 라파에트")) {
									
									btn59.setIcon(icon56);
									
								}
								else if(msg.equals("p2 캐릭터 : 바트 캐시디")) {
									
									btn59.setIcon(icon55);
									
								}
								else if(msg.equals("p4 캐릭터 : 시드케첨")) {
									
									btn64.setIcon(icon66);
									
								}
								else if(msg.equals("p4 캐릭터 : 로즈 뮬란")) {
									
									btn64.setIcon(icon62);
								
								}
								else if(msg.equals("p4 캐릭터 : 캘러미티 자넷")) {
									
									btn64.setIcon(icon68);
									
								}
								else if(msg.equals("p4 캐릭터 : 윌리 더 키드")) {
									
									btn64.setIcon(icon67);
								
								}
								else if(msg.equals("p4 캐릭터 : 폴 리그레트")) {
									
									btn64.setIcon(icon69);
									
								}
								else if(msg.equals("p4 캐릭터 : 슬랩 더 킬러")) {
									
									btn64.setIcon(icon65);
						
								}
								else if(msg.equals("p4 캐릭터 : 수지 라파에트")) {
									
									btn64.setIcon(icon64);
						
								}
								else if(msg.equals("p4 캐릭터 : 바트 캐시디")) {
									
									btn64.setIcon(icon63);
				
								}
								if(msg.equals("p1hp : 5") ) {
									btn58.setIcon(icon74);
									btn53.setIcon(icon73);
									btn65.setIcon(icon74);
								 }
								 else if((msg.equals("p1hp : 4")&&msg.equals("p1 캐릭터 : 폴 리그레트"))) {
									 btn58.setIcon(icon74);
										btn53.setIcon(icon73);
										btn65.setIcon(icon74);
								 }
							
								 if(msg.equals("p2hp : 5") ) {
										btn58.setIcon(icon70);
										btn53.setIcon(icon73);
										btn65.setIcon(icon74);
									}
								 else if((msg.equals("p2hp : 4")&&msg.equals("p2 캐릭터 : 폴 리그레트"))) {
									 btn58.setIcon(icon70);
									 btn53.setIcon(icon73);
									btn65.setIcon(icon74);
								 }
								 if(msg.equals("p3hp : 5") ) {
									 btn58.setIcon(icon74);
									 btn53.setIcon(icon71);
									 btn65.setIcon(icon74);
								 }
								 else if( (msg.equals("p3hp : 4")&&msg.equals("p3 캐릭터 : 폴 리그레트"))) {
									 btn58.setIcon(icon74);
									 btn53.setIcon(icon71);
									 btn65.setIcon(icon74);
								 }
								 if(msg.equals("p4hp : 5") ) {
									 btn58.setIcon(icon74);
									 btn53.setIcon(icon73);
									 btn65.setIcon(icon72);
								 }
								 else if((msg.equals("p4hp : 4")&&msg.equals("p4 캐릭터 : 폴 리그레트"))) {
									 btn58.setIcon(icon74);
									 btn53.setIcon(icon73);
									 btn65.setIcon(icon72);
								 }
								
								}
								
								
								
								
								
								
								if(id.equals("3")) {
									if(msg.equals("p3hp : 5")) {
										btn66.setIcon(icon31);
									}
									else if(msg.equals("p3hp : 4")) {
										btn66.setIcon(icon32);
									}
									else if(msg.equals("p3hp : 3")) {
										btn66.setIcon(icon33);
									}
									else if(msg.equals("p3hp : 2")) {
										btn66.setIcon(icon34);
									}
									else if(msg.equals("p3hp : 1")) {
										btn66.setIcon(icon35);
									}
									else if(msg.equals("p1hp : 5")) {
										btn67.setIcon(icon36);
										btn53.setIcon(icon71);
									}
									else if(msg.equals("p1hp : 4")) {
										btn67.setIcon(icon37);
									}
									else if(msg.equals("p1hp : 3")) {
										btn67.setIcon(icon38);
									}
									else if(msg.equals("p1hp : 2")) {
										btn67.setIcon(icon39);
									}
									else if(msg.equals("p1hp : 1")) {
										btn67.setIcon(icon40);
									}
									else if(msg.equals("p4hp : 5")) {
										btn68.setIcon(icon41);
									}
									else if(msg.equals("p4hp : 4")) {
										btn68.setIcon(icon42);
									}
									else if(msg.equals("p4hp : 3")) {
										btn68.setIcon(icon43);
									}
									else if(msg.equals("p4hp : 2")) {
										btn68.setIcon(icon44);
									}
									else if(msg.equals("p4hp : 1")) {
										btn68.setIcon(icon45);
									}
									else if(msg.equals("p2hp : 5")) {
										btn69.setIcon(icon41);
									}
									else if(msg.equals("p2hp : 4")) {
										btn69.setIcon(icon42);
									}
									else if(msg.equals("p2hp : 3")) {
										btn69.setIcon(icon43);
									}
									else if(msg.equals("p2hp : 2")) {
										btn69.setIcon(icon44);
									}
									else if(msg.equals("p2hp : 1")) {
										btn69.setIcon(icon45);
									}
									else if(msg.equals("3번 플레이어 직업 무법자")) {
										
										btn3.setIcon(icon1);
									}
									else if(msg.equals("3번 플레이어 직업 배신자")) {
										
										btn3.setIcon(icon2);
									}
									else if(msg.equals("3번 플레이어 직업 보안관")) {
		
										btn3.setIcon(icon3);
									}
									else if(msg.equals("3번 플레이어 직업 부관")) {
										
										btn3.setIcon(icon4);
									}
									else if(msg.equals("p3 캐릭터 : 시드케첨")) {
										
										btn5.setIcon(icon9);
										
									}
									else if(msg.equals("p3 캐릭터 : 로즈 뮬란")) {
										
										btn5.setIcon(icon5);
		
									}
									else if(msg.equals("p3 캐릭터 : 캘러미티 자넷")) {
										
										btn5.setIcon(icon11);
		
									}
									else if(msg.equals("p3 캐릭터 : 윌리 더 키드")) {
										
										btn5.setIcon(icon10);
					
									}
									else if(msg.equals("p3 캐릭터 : 폴 리그레트")) {
										
										btn5.setIcon(icon12);
				
									}
									else if(msg.equals("p3 캐릭터 : 슬랩 더 킬러")) {
										
										btn5.setIcon(icon8);

									}
									else if(msg.equals("p3 캐릭터 : 수지 라파에트")) {
										
										btn5.setIcon(icon7);
			
									}
									else if(msg.equals("p3 캐릭터 : 바트 캐시디")) {
										
										btn5.setIcon(icon6);
				
									}
									else if(msg.equals("p1 캐릭터 : 시드케첨")) {
										
										btn52.setIcon(icon50);
					
									}
									else if(msg.equals("p1 캐릭터 : 로즈 뮬란")) {
										
										btn52.setIcon(icon46);

									}
									else if(msg.equals("p1 캐릭터 : 캘러미티 자넷")) {
										
										btn52.setIcon(icon52);
			
									}
									else if(msg.equals("p1 캐릭터 : 윌리 더 키드")) {
										
										btn52.setIcon(icon51);
								
									}
									else if(msg.equals("p1 캐릭터 : 폴 리그레트")) {
										
										btn52.setIcon(icon53);
			
									}
									else if(msg.equals("p1 캐릭터 : 슬랩 더 킬러")) {
										
										btn52.setIcon(icon49);
					
									}
									else if(msg.equals("p1 캐릭터 : 수지 라파에트")) {
										
										btn52.setIcon(icon48);
					
									}
									else if(msg.equals("p1 캐릭터 : 바트 캐시디")) {
										
										btn52.setIcon(icon47);
					
									}
									else if(msg.equals("p4 캐릭터 : 시드케첨")) {
										
										btn59.setIcon(icon58);
						
									}
									else if(msg.equals("p4 캐릭터 : 로즈 뮬란")) {
										
										btn59.setIcon(icon54);
			
									}
									else if(msg.equals("p4 캐릭터 : 캘러미티 자넷")) {
										
										btn59.setIcon(icon60);
					
									}
									else if(msg.equals("p4 캐릭터 : 윌리 더 키드")) {
										
										btn59.setIcon(icon59);
					
									}
									else if(msg.equals("p4 캐릭터 : 폴 리그레트")) {
										
										btn59.setIcon(icon61);
			
									}
									else if(msg.equals("p4 캐릭터 : 슬랩 더 킬러")) {
										
										btn59.setIcon(icon57);
						
									}
									else if(msg.equals("p4 캐릭터 : 수지 라파에트")) {
										
										btn59.setIcon(icon56);
						
									}
									else if(msg.equals("p4 캐릭터 : 바트 캐시디")) {
										
										btn59.setIcon(icon55);
					
									}
									else if(msg.equals("p3 캐릭터 : 시드케첨")) {
										
										btn64.setIcon(icon66);
					
										
									}
									else if(msg.equals("p2 캐릭터 : 로즈 뮬란")) {
										
										btn64.setIcon(icon62);
							
									}
									else if(msg.equals("p2 캐릭터 : 캘러미티 자넷")) {
										
										btn64.setIcon(icon68);
					
									}
									else if(msg.equals("p2 캐릭터 : 윌리 더 키드")) {
										
										btn64.setIcon(icon67);
						
									}
									else if(msg.equals("p2 캐릭터 : 폴 리그레트")) {
										
										btn64.setIcon(icon69);
					
									}
									else if(msg.equals("p2 캐릭터 : 슬랩 더 킬러")) {
										
										btn64.setIcon(icon65);
						
									}
									else if(msg.equals("p2 캐릭터 : 수지 라파에트")) {
										
										btn64.setIcon(icon64);
						
									}
									else if(msg.equals("p2 캐릭터 : 바트 캐시디")) {
										
										btn64.setIcon(icon63);
					
									}
									 if(msg.equals("p1hp : 5") ) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon71);
										 btn65.setIcon(icon74);
									 }
									 else if((msg.equals("p1hp : 4")&&msg.equals("p1 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon71);
										 btn65.setIcon(icon74);
									 }
									 if(msg.equals("p2hp : 5") ) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon73);
										 btn65.setIcon(icon72);
									 }
									 else if((msg.equals("p2hp : 4")&&msg.equals("p2 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon73);
										 btn65.setIcon(icon72);
									 }
									 if(msg.equals("p3hp : 5") ) {
											btn58.setIcon(icon74);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
										 }
									 else if((msg.equals("p3hp : 4")&&msg.equals("p3 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon74);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
									 }
									 
									 
									 if(msg.equals("p4hp : 5") ) {
										btn58.setIcon(icon70);
										btn53.setIcon(icon73);
										btn65.setIcon(icon74);
									 }
									 else if((msg.equals("p4hp : 4")&&msg.equals("p4 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon70);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
									 }
								}
								
								
								if(id.equals("2")) {
									if(msg.equals("p2hp : 5")) {
										btn66.setIcon(icon31);
									}
									else if(msg.equals("p2hp : 4")) {
										btn66.setIcon(icon32);
									}
									else if(msg.equals("p2hp : 3")) {
										btn66.setIcon(icon33);
									}
									else if(msg.equals("p2hp : 2")) {
										btn66.setIcon(icon34);
									}
									else if(msg.equals("p2hp : 1")) {
										btn66.setIcon(icon35);
									}
									else if(msg.equals("p4hp : 5")) {
										btn67.setIcon(icon36);
									}
									else if(msg.equals("p4hp : 4")) {
										btn67.setIcon(icon37);
									}
									else if(msg.equals("p4hp : 3")) {
										btn67.setIcon(icon38);
									}
									else if(msg.equals("p4hp : 2")) {
										btn67.setIcon(icon39);
									}
									else if(msg.equals("p4hp : 1")) {
										btn67.setIcon(icon40);
									}
									else if(msg.equals("p3hp : 5")) {
										btn68.setIcon(icon41);
									}
									else if(msg.equals("p3hp : 4")) {
										btn68.setIcon(icon42);
									}
									else if(msg.equals("p3hp : 3")) {
										btn68.setIcon(icon43);
									}
									else if(msg.equals("p3hp : 2")) {
										btn68.setIcon(icon44);
									}
									else if(msg.equals("p3hp : 1")) {
										btn68.setIcon(icon45);
									}
									else if(msg.equals("p1hp : 5")) {
										btn69.setIcon(icon41);
									}
									else if(msg.equals("p1hp : 4")) {
										btn69.setIcon(icon42);
									}
									else if(msg.equals("p1hp : 3")) {
										btn69.setIcon(icon43);
									}
									else if(msg.equals("p1hp : 2")) {
										btn69.setIcon(icon44);
									}
									else if(msg.equals("p1hp : 1")) {
										btn69.setIcon(icon45);
									}
								
									else if(msg.equals("2번 플레이어 직업 무법자")) {
										
										btn3.setIcon(icon1);
									}
									else if(msg.equals("2번 플레이어 직업 배신자")) {
										
										btn3.setIcon(icon2);
									}
									else if(msg.equals("2번 플레이어 직업 보안관")) {
		
										btn3.setIcon(icon3);
									}
									else if(msg.equals("2번 플레이어 직업 부관")) {
										
										btn3.setIcon(icon4);
									}
									else if(msg.equals("p2 캐릭터 : 시드케첨")) {
										
										btn5.setIcon(icon9);
				
									}
									else if(msg.equals("p2 캐릭터 : 로즈 뮬란")) {
										
										btn5.setIcon(icon5);
						
									}
									else if(msg.equals("p2 캐릭터 : 캘러미티 자넷")) {
										
										btn5.setIcon(icon11);
						
									}
									else if(msg.equals("p2 캐릭터 : 윌리 더 키드")) {
										
										btn5.setIcon(icon10);
				
									}
									else if(msg.equals("p2 캐릭터 : 폴 리그레트")) {
										
										btn5.setIcon(icon12);
					
									}
									else if(msg.equals("p2 캐릭터 : 슬랩 더 킬러")) {
										
										btn5.setIcon(icon8);
					
									}
									else if(msg.equals("p2 캐릭터 : 수지 라파에트")) {
										
										btn5.setIcon(icon7);
						
									}
									else if(msg.equals("p2 캐릭터 : 바트 캐시디")) {
										
										btn5.setIcon(icon6);
				
									}
									else if(msg.equals("p4 캐릭터 : 시드케첨")) {
										
										btn52.setIcon(icon50);
			
									}
									else if(msg.equals("p4 캐릭터 : 로즈 뮬란")) {
										
										btn52.setIcon(icon46);
									
									}
									else if(msg.equals("p4 캐릭터 : 캘러미티 자넷")) {
										
										btn52.setIcon(icon52);
						
									}
									else if(msg.equals("p4 캐릭터 : 윌리 더 키드")) {
										
										btn52.setIcon(icon51);
					
									}
									else if(msg.equals("p4 캐릭터 : 폴 리그레트")) {
										
										btn52.setIcon(icon53);
			
									}
									else if(msg.equals("p4 캐릭터 : 슬랩 더 킬러")) {
										
										btn52.setIcon(icon49);
				
									}
									else if(msg.equals("p4 캐릭터 : 수지 라파에트")) {
										
										btn52.setIcon(icon48);
					
									}
									else if(msg.equals("p4 캐릭터 : 바트 캐시디")) {
										
										btn52.setIcon(icon47);
						
									}
									else if(msg.equals("p3 캐릭터 : 시드케첨")) {
										
										btn59.setIcon(icon58);
						
									}
									else if(msg.equals("p3 캐릭터 : 로즈 뮬란")) {
										
										btn59.setIcon(icon54);
							
									}
									else if(msg.equals("p3 캐릭터 : 캘러미티 자넷")) {
										
										btn59.setIcon(icon60);
						
									}
									else if(msg.equals("p3 캐릭터 : 윌리 더 키드")) {
										
										btn59.setIcon(icon59);
						
									}
									else if(msg.equals("p3 캐릭터 : 폴 리그레트")) {
										
										btn59.setIcon(icon61);
						
									}
									else if(msg.equals("p3 캐릭터 : 슬랩 더 킬러")) {
										
										btn59.setIcon(icon57);
					
									}
									else if(msg.equals("p3 캐릭터 : 수지 라파에트")) {
										
										btn59.setIcon(icon56);
					
									}
									else if(msg.equals("p3 캐릭터 : 바트 캐시디")) {
										
										btn59.setIcon(icon55);
							
									}
									else if(msg.equals("p1 캐릭터 : 시드케첨")) {
										
										btn64.setIcon(icon66);
					
									}
									else if(msg.equals("p1 캐릭터 : 로즈 뮬란")) {
										
										btn64.setIcon(icon62);
						
									}
									else if(msg.equals("p1 캐릭터 : 캘러미티 자넷")) {
										
										btn64.setIcon(icon68);
								
									}
									else if(msg.equals("p1 캐릭터 : 윌리 더 키드")) {
										
										btn64.setIcon(icon67);
								
									}
									else if(msg.equals("p1 캐릭터 : 폴 리그레트")) {
										
										btn64.setIcon(icon69);
					
									}
									else if(msg.equals("p1 캐릭터 : 슬랩 더 킬러")) {
										
										btn64.setIcon(icon65);
								
									}
									else if(msg.equals("p1 캐릭터 : 수지 라파에트")) {
										
										btn64.setIcon(icon64);
								
									}
									else if(msg.equals("p1 캐릭터 : 바트 캐시디")) {
										
										btn64.setIcon(icon63);
								
									}
									 if(msg.equals("p1hp : 5") ) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon73);
										 btn65.setIcon(icon72);
										 
										}
									 else if((msg.equals("p1hp : 4")&&msg.equals("p1 캐릭터 : 폴 리그레트"))) {
											btn65.setIcon(icon72);
										}
									 
									 if(msg.equals("p2hp : 5") ) {
											btn58.setIcon(icon74);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
										 }
									 else if((msg.equals("p2hp : 4")&&msg.equals("p2 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon74);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
										}
									 if(msg.equals("p3hp : 5") ) {
										 btn58.setIcon(icon70);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
									 }
									 else if( (msg.equals("p3hp : 4")&&msg.equals("p3 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon70);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
									 }
									 if(msg.equals("p4hp : 5") ) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon71);
										 btn65.setIcon(icon74);
									 }
									 else if((msg.equals("p4hp : 4")&&msg.equals("p4 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon71);
										 btn65.setIcon(icon74);
										}
								}
								
								if(id.equals("4")) {
									if(msg.equals("p4hp : 5")) {
										btn66.setIcon(icon31);
									}
									else if(msg.equals("p4hp : 4")) {
										btn66.setIcon(icon32);
									}
									else if(msg.equals("p4hp : 3")) {
										btn66.setIcon(icon33);
									}
									else if(msg.equals("p4hp : 2")) {
										btn66.setIcon(icon34);
									}
									else if(msg.equals("p4hp : 1")) {
										btn66.setIcon(icon35);
									}
									else if(msg.equals("p2hp : 5")) {
										btn67.setIcon(icon36);
										btn53.setIcon(icon71);
									}
									else if(msg.equals("p2hp : 4")) {
										btn67.setIcon(icon37);
									}
									else if(msg.equals("p2hp : 3")) {
										btn67.setIcon(icon38);
									}
									else if(msg.equals("p2hp : 2")) {
										btn67.setIcon(icon39);
									}
									else if(msg.equals("p2hp : 1")) {
										btn67.setIcon(icon40);
									}
									else if(msg.equals("p1hp : 5")) {
										btn68.setIcon(icon41);
									}
									else if(msg.equals("p1hp : 4")) {
										btn68.setIcon(icon42);
									}
									else if(msg.equals("p1hp : 3")) {
										btn68.setIcon(icon43);
									}
									else if(msg.equals("p1hp : 2")) {
										btn68.setIcon(icon44);
									}
									else if(msg.equals("p1hp : 1")) {
										btn68.setIcon(icon45);
									}
									else if(msg.equals("p3hp : 5")) {
										btn69.setIcon(icon41);
									}
									else if(msg.equals("p3hp : 4")) {
										btn69.setIcon(icon42);
									}
									else if(msg.equals("p3hp : 3")) {
										btn69.setIcon(icon43);
									}
									else if(msg.equals("p3hp : 2")) {
										btn69.setIcon(icon44);
									}
									else if(msg.equals("p3hp : 1")) {
										btn69.setIcon(icon45);
									}
								
									else if(msg.equals("4번 플레이어 직업 무법자")) {
										
										btn3.setIcon(icon1);
									}
									else if(msg.equals("4번 플레이어 직업 배신자")) {
										
										btn3.setIcon(icon2);
									}
									else if(msg.equals("4번 플레이어 직업 보안관")) {
		
										btn3.setIcon(icon3);
									}
									else if(msg.equals("4번 플레이어 직업 부관")) {
										
										btn3.setIcon(icon4);
									}
									else if(msg.equals("p4 캐릭터 : 시드케첨")) {
										
										btn5.setIcon(icon9);
				
									}
									else if(msg.equals("p4 캐릭터 : 로즈 뮬란")) {
										
										btn5.setIcon(icon5);
						
									}
									else if(msg.equals("p4 캐릭터 : 캘러미티 자넷")) {
										
										btn5.setIcon(icon11);
					
									}
									else if(msg.equals("p4 캐릭터 : 윌리 더 키드")) {
										
										btn5.setIcon(icon10);
		
									}
									else if(msg.equals("p4 캐릭터 : 폴 리그레트")) {
										
										btn5.setIcon(icon12);
				
									}
									else if(msg.equals("p4 캐릭터 : 슬랩 더 킬러")) {
										
										btn5.setIcon(icon8);
		
									}
									else if(msg.equals("p4 캐릭터 : 수지 라파에트")) {
										
										btn5.setIcon(icon7);
							
									}
									else if(msg.equals("p4 캐릭터 : 바트 캐시디")) {
										
										btn5.setIcon(icon6);
					
									}
									else if(msg.equals("p2 캐릭터 : 시드케첨")) {
										
										btn52.setIcon(icon50);
				
									}
									else if(msg.equals("p2 캐릭터 : 로즈 뮬란")) {
										
										btn52.setIcon(icon46);
			
									}
									else if(msg.equals("p2 캐릭터 : 캘러미티 자넷")) {
										
										btn52.setIcon(icon52);
					
									}
									else if(msg.equals("p2 캐릭터 : 윌리 더 키드")) {
										
										btn52.setIcon(icon51);
					
									}
									else if(msg.equals("p2 캐릭터 : 폴 리그레트")) {
										
										btn52.setIcon(icon53);
					
									}
									else if(msg.equals("p2 캐릭터 : 슬랩 더 킬러")) {
										
										btn52.setIcon(icon49);
					
									}
									else if(msg.equals("p2 캐릭터 : 수지 라파에트")) {
										
										btn52.setIcon(icon48);
			
									}
									else if(msg.equals("p2 캐릭터 : 바트 캐시디")) {
										
										btn52.setIcon(icon47);
					
									}
									else if(msg.equals("p1 캐릭터 : 시드케첨")) {
										
										btn59.setIcon(icon58);
			
									}
									else if(msg.equals("p1 캐릭터 : 로즈 뮬란")) {
										
										btn59.setIcon(icon54);
				
									}
									else if(msg.equals("p1 캐릭터 : 캘러미티 자넷")) {
										
										btn59.setIcon(icon60);
						
									}
									else if(msg.equals("p1 캐릭터 : 윌리 더 키드")) {
										
										btn59.setIcon(icon59);
						
									}
									else if(msg.equals("p1 캐릭터 : 폴 리그레트")) {
										
										btn59.setIcon(icon61);
					
									}
									else if(msg.equals("p1 캐릭터 : 슬랩 더 킬러")) {
										
										btn59.setIcon(icon57);
				
									}
									else if(msg.equals("p1 캐릭터 : 수지 라파에트")) {
										
										btn59.setIcon(icon56);
		
									}
									else if(msg.equals("p1 캐릭터 : 바트 캐시디")) {
										
										btn59.setIcon(icon55);
				
									}
									else if(msg.equals("p3 캐릭터 : 시드케첨")) {
										
										btn64.setIcon(icon66);
			
									}
									else if(msg.equals("p3 캐릭터 : 로즈 뮬란")) {
										
										btn64.setIcon(icon62);
			
									}
									else if(msg.equals("p3 캐릭터 : 캘러미티 자넷")) {
										
										btn64.setIcon(icon68);
			
									}
									else if(msg.equals("p3 캐릭터 : 윌리 더 키드")) {
										
										btn64.setIcon(icon67);
			
									}
									else if(msg.equals("p3 캐릭터 : 폴 리그레트")) {
										
										btn64.setIcon(icon69);
						
									}
									else if(msg.equals("p3 캐릭터 : 슬랩 더 킬러")) {
										
										btn64.setIcon(icon65);
			
									}
									else if(msg.equals("p3 캐릭터 : 수지 라파에트")) {
										
										btn64.setIcon(icon64);
					
									}
									else if(msg.equals("p3 캐릭터 : 바트 캐시디")) {
										
										btn64.setIcon(icon63);
				
									}
									 if(msg.equals("p1hp : 5") ) {
										 btn58.setIcon(icon70);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
										}
									 else if( (msg.equals("p1hp : 4")&&msg.equals("p1 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon70);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
										}
									 if(msg.equals("p2hp : 5") ) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon71);
										 btn65.setIcon(icon74);
									 }
									 else if( (msg.equals("p2hp : 4")&&msg.equals("p2 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon71);
										 btn65.setIcon(icon74);
										}
									 if(msg.equals("p3hp : 5") ) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon73);
										 btn65.setIcon(icon72);
									 }
									 else if( (msg.equals("p3hp : 4")&&msg.equals("p3 캐릭터 : 폴 리그레트"))) {
										 btn58.setIcon(icon74);
										 btn53.setIcon(icon73);
										 btn65.setIcon(icon72);
										}
									 if(msg.equals("p4hp : 5") ) {
											btn58.setIcon(icon74);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
										 }
									 else if( (msg.equals("p4hp : 4")&&msg.equals("p4 캐릭터 : 폴 리그레트"))) {
											btn58.setIcon(icon74);
											btn53.setIcon(icon73);
											btn65.setIcon(icon74);
										}
								}
								
								
								if(msg.equals("1번 플레이어 순서: 1번")) {
									kong("1");
									
								}
								else if(msg.equals("1번 플레이어 순서: 2번")) {
									kong("2");
									
								}
								else if(msg.equals("1번 플레이어 순서: 3번")) {
									kong("3");
									
								}
								else if(msg.equals("1번 플레이어 순서: 4번")) {
									kong("4");
									
								}
								
								
								if(msg.equals("2번 플레이어 순서: 1번")) {
									kong("5");
									
								}
								else if(msg.equals("2번 플레이어 순서: 2번")) {
									kong("6");
									
								}
								else if(msg.equals("2번 플레이어 순서: 3번")) {
									kong("7");
									
								}
								else if(msg.equals("2번 플레이어 순서: 4번")) {
									kong("8");
									
								}
								
								
								if(msg.equals("3번 플레이어 순서: 1번")) {
									kong("9");
									
								}
								else if(msg.equals("3번 플레이어 순서: 2번")) {
									kong("10");
									
								}
								else if(msg.equals("3번 플레이어 순서: 3번")) {
									kong("11");
									
								}
								else if(msg.equals("3번 플레이어 순서: 4번")) {
									kong("12");
									
								}
								
								
								if(msg.equals("4번 플레이어 순서: 1번")) {
									kong("13");
									
								}
								else if(msg.equals("4번 플레이어 순서: 2번")) {
									kong("14");
									
								}
								else if(msg.equals("4번 플레이어 순서: 3번")) {
									kong("15");
									
								}
								else if(msg.equals("4번 플레이어 순서: 4번")) {
									kong("16");
									
								}
								
							} catch (IOException e) {
								textArea.append("오류검출3번\n");
								
								try {
									os.close();
									is.close();
									dos.close();
									dis.close();
									socket.close();
									break;
								} catch (IOException e1) {

								}

							}
						} // while

					}// run
				});

		th.start();

	}
	
	public void send_Message(String str) { 
		try {
			dos.writeUTF(str);
			
			
		} catch (IOException e) {
			textArea.append("오류검출4번\n");
			
		}
	}
	
	public void init() { 
		
		this.setTitle("bang");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        MyPanel panel = new MyPanel();
        panel.setLayout(new FlowLayout());
	
        //캐릭터랑 hp랑 장착아이템
		btn1.setBounds(600, 245, 150, 245);
        btn2.setBounds(800, 245, 150, 245);
        btn3.setBounds(550, 650, 80, 125);
        btn5.setBounds(640, 650, 80, 125); 
      
        //패 버튼 위치 조정
        btn9.setBounds(800, 600, 65, 97);
        btn11.setBounds(870, 600, 65, 97);
        btn12.setBounds(940, 600, 65, 97);
        btn10.setBounds(800, 700, 65, 97);
        btn13.setBounds(870, 700, 65, 97);
        btn14.setBounds(940, 700, 65, 97);
       
        //상대 버튼위치 조정
        btn21.setBounds(570, 10, 40, 67);
        btn22.setBounds(615, 10, 40, 67);
        btn23.setBounds(660, 10, 40, 67);  
        btn26.setBounds(570, 80, 40, 67);
        btn27.setBounds(615, 80, 40, 67);
        btn28.setBounds(660, 80, 40, 67);
        
        //상대 버튼위치 조정2
        
        btn31.setBounds(10, 240, 67, 40);
        btn32.setBounds(10, 285, 67, 40);
        btn33.setBounds(10, 330, 67, 40);    
        btn36.setBounds(83, 240, 67, 40);
        btn37.setBounds(83, 285, 67, 40);
        btn38.setBounds(83, 330, 67, 40);
        
        //상대 버튼위치 조정3
     
        btn41.setBounds(1335, 240, 67, 40);
        btn42.setBounds(1335, 285, 67, 40);
        btn43.setBounds(1335, 330, 67, 40); 
        btn46.setBounds(1407, 240, 67, 40);
        btn47.setBounds(1407, 285, 67, 40);
        btn48.setBounds(1407, 330, 67, 40);
        
        //북쪽상대 프로필창
       
        btn52.setBounds(730, 10, 65, 97);
        btn53.setBounds(800, 10, 65, 97);
       
        
        //서쪽상대 프로필
      
        btn58.setBounds(10, 385, 97, 65);
        btn59.setBounds(10, 455, 97, 65);
       
        
        //동쪽상대 프로필
        btn64.setBounds(1375, 385, 97, 65);
        btn65.setBounds(1375, 455, 97, 65);
        
        
        //본인 체력
        btn66.setBounds(550, 600, 170, 40);
        //윗새끼 체력
        btn67.setBounds(730, 110, 135, 40);
        //왼쪽새끼 체력
        btn68.setBounds(110, 385, 40, 135);
        //오른쪽새끼 체력
        btn69.setBounds(1330, 385, 40, 135);
      
        //채팅창 해놓은거 여기에 들어감
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 595, 450, 200);
		this.getContentPane().add(scrollPane);

		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setFont(F);
		textArea.setForeground(Color.black);
		
		textField = new JTextField();
		textField.setBounds(0, 800, 450, 42);
		this.getContentPane().add(textField);
		textField.setColumns(10);
		

		sendBtn = new JButton("send");
		sendBtn.setBounds(460, 800, 50, 42);
		
		//판넬에 추가하는거임
		this.getContentPane().add(sendBtn);
		this.getContentPane().add(btn1);
        this.getContentPane().add(btn2);
        this.getContentPane().add(btn3);
        this.getContentPane().add(btn5);
       
        this.getContentPane().add(btn9);
        this.getContentPane().add(btn10);
        this.getContentPane().add(btn11);
        this.getContentPane().add(btn12);
        this.getContentPane().add(btn13);
        this.getContentPane().add(btn14);
          
        this.getContentPane().add(btn21);
        this.getContentPane().add(btn22);
        this.getContentPane().add(btn23);
        this.getContentPane().add(btn26);
        this.getContentPane().add(btn27);
        this.getContentPane().add(btn28);
        
        this.getContentPane().add(btn31);
        this.getContentPane().add(btn32);
        this.getContentPane().add(btn33);
        this.getContentPane().add(btn36);
        this.getContentPane().add(btn37);
        this.getContentPane().add(btn38);
        
        this.getContentPane().add(btn41);
        this.getContentPane().add(btn42);
        this.getContentPane().add(btn43);
        this.getContentPane().add(btn46);
        this.getContentPane().add(btn47);
        this.getContentPane().add(btn48);
        
        this.getContentPane().add(btn52);
        this.getContentPane().add(btn53);
        
        this.getContentPane().add(btn58);
        this.getContentPane().add(btn59);
        
        this.getContentPane().add(btn64);
        this.getContentPane().add(btn65);
        this.getContentPane().add(btn66);
        this.getContentPane().add(btn67);
        this.getContentPane().add(btn68);
        this.getContentPane().add(btn69);
        //여기도 판넬본인 추가 + 사이즈랑 보이게하는거 
		textArea.setEnabled(false); 
		this.add(panel);
        this.setSize(1500,900);
        this.setVisible(true);	
	}
	
	public void start() { 

		sendBtn.addActionListener(new Myaction()); 
		btn9.addActionListener(new Myaction2());  //뱅
		btn10.addActionListener(new Myaction3()); //미스
		btn11.addActionListener(new Myaction4()); //카드선택
		btn13.addActionListener(new Myaction5());//넘기기
		btn12.addActionListener(new Myaction6());  //상대방선택
		btn14.addActionListener(new Myaction7());  //상대방선택2

	}
	
	class Ad {
		
		public void button(String a) {
			
		}
		
	}

	class Myaction implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			if (e.getSource() == sendBtn)
			{

				send_Message(textField.getText());
				textField.setText(""); 
				textField.requestFocus(); 	
			}

		}
		

	}
	
	class Myaction2 implements ActionListener{ //뱅
		
		@Override
		public void actionPerformed(ActionEvent t) {
			if(id.equals("1")) {
				if (t.getSource() == btn9)
				{
					btn9.setIcon(icon13);
					String a = "11";
					send_Message(a);
				}
			}
			if(id.equals("2")) {
				if (t.getSource() == btn9)
				{
					btn9.setIcon(icon13);
					String a = "21";
					send_Message(a);
				}
			}
			if(id.equals("3")) {
				if (t.getSource() == btn9)
				{
					btn9.setIcon(icon13);
					String a = "31";
					send_Message(a);
				}
			}
			if(id.equals("4")) {
				if (t.getSource() == btn9)
				{
					btn9.setIcon(icon13);
					String a = "41";
					send_Message(a);
				}
			}
		}
	}
	
	class Myaction3 implements ActionListener{ //빗나감
		
		@Override
		public void actionPerformed(ActionEvent t) {
			if(id.equals("1")) {
				if (t.getSource() == btn10)
				{
					btn10.setIcon(icon14);
					String a = "12";
					send_Message(a);
				}
			}
			if(id.equals("2")) {
				if (t.getSource() == btn10)
				{
					btn10.setIcon(icon14);
					String a = "22";
					send_Message(a);
				}
			}
			if(id.equals("3")) {
				if (t.getSource() == btn10)
				{
					btn10.setIcon(icon14);
					String a = "32";
					send_Message(a);
				}
			}
			if(id.equals("4")) {
				if (t.getSource() == btn10)
				{
					btn10.setIcon(icon14);
					String a = "42";
					send_Message(a);
				}
			}
		}
	}
	
	
	String msg2;
	public void kong(String str2) {
		msg2 = str2;
	}
	
class Myaction4 implements ActionListener{   //카드선택
		
		@Override
		public void actionPerformed(ActionEvent t) {
			if(msg2.equals("1")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "1";
					send_Message(a);
				}
				
			}
			if( msg2.equals("2")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "3";
					send_Message(a);
				}
				
			}
			if(msg2.equals("3")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "5";
					send_Message(a);
				}
				
			}
			if( msg2.equals("4")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "7";
					send_Message(a);
				}
				
			}
			if(msg2.equals("5")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "1";
					send_Message(a);
				}
				
			}
			if( msg2.equals("6")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "3";
					send_Message(a);
				}
				
			}
			if(msg2.equals("7")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "5";
					send_Message(a);
				}
				
			}
			if( msg2.equals("8")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "7";
					send_Message(a);
				}
				
			}
			if(msg2.equals("9")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "1";
					send_Message(a);
				}
				
			}
			if( msg2.equals("10")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "3";
					send_Message(a);
				}
				
			}
			if(msg2.equals("11")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "5";
					send_Message(a);
				}
				
			}
			if( msg2.equals("12")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "7";
					send_Message(a);
				}
				
			}
			if(msg2.equals("13")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "1";
					send_Message(a);
				}
				
			}
			if( msg2.equals("14")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "3";
					send_Message(a);
				}
				
			}
			if(msg2.equals("15")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "5";
					send_Message(a);
				}
				
			}
			if( msg2.equals("16")) {
				if (t.getSource() == btn11)
				{
					btn11.setIcon(icon15);
					String a = "7";
					send_Message(a);
				}
				
			}
		}
	}
	
	class Myaction5 implements ActionListener{   //넘기기
		
		@Override
		public void actionPerformed(ActionEvent t) {
			
			if(msg2.equals("1")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "2";
					send_Message(a);
				}
				
			}
			if( msg2.equals("2")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "4";
					send_Message(a);
				}
				
			}
			if(msg2.equals("3")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "6";
					send_Message(a);
				}
				
			}
			if( msg2.equals("4")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "8";
					send_Message(a);
				}
				
			}
			if(msg2.equals("5")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "2";
					send_Message(a);
				}
				
			}
			if( msg2.equals("6")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "4";
					send_Message(a);
				}
				
			}
			if(msg2.equals("7")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "6";
					send_Message(a);
				}
				
			}
			if( msg2.equals("8")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "8";
					send_Message(a);
				}
				
			}
			if(msg2.equals("9")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "2";
					send_Message(a);
				}
				
			}
			if( msg2.equals("10")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "4";
					send_Message(a);
				}
				
			}
			if(msg2.equals("11")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "6";
					send_Message(a);
				}
				
			}
			if( msg2.equals("12")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "8";
					send_Message(a);
				}
				
			}
			if(msg2.equals("13")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "2";
					send_Message(a);
				}
				
			}
			if( msg2.equals("14")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "4";
					send_Message(a);
				}
				
			}
			if(msg2.equals("15")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "6";
					send_Message(a);
				}
				
			}
			if( msg2.equals("16")) {
				if (t.getSource() == btn13)
				{
					btn13.setIcon(icon15);
					String a = "8";
					send_Message(a);
				}
				
			}
		}
	}
	
	class Myaction6 implements ActionListener{ //상대방선택
		
		@Override
		public void actionPerformed(ActionEvent t) {
			if(msg2.equals("1")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "13";
					send_Message(a);
				}
				
			}
			if( msg2.equals("2")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "23";
					send_Message(a);
				}
				
			}
			if(msg2.equals("3")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "33";
					send_Message(a);
				}
				
			}
			if( msg2.equals("4")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "43";
					send_Message(a);
				}
				
			}
			if(msg2.equals("5")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "13";
					send_Message(a);
				}
				
			}
			if( msg2.equals("6")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "23";
					send_Message(a);
				}
				
			}
			if(msg2.equals("7")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "33";
					send_Message(a);
				}
				
			}
			if( msg2.equals("8")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "43";
					send_Message(a);
				}
				
			}
			if(msg2.equals("9")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "13";
					send_Message(a);
				}
				
			}
			if( msg2.equals("10")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "23";
					send_Message(a);
				}
				
			}
			if(msg2.equals("11")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "33";
					send_Message(a);
				}
				
			}
			if( msg2.equals("12")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "43";
					send_Message(a);
				}
				
			}
			if(msg2.equals("13")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "13";
					send_Message(a);
				}
				
			}
			if( msg2.equals("14")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "23";
					send_Message(a);
				}
				
			}
			if(msg2.equals("15")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "33";
					send_Message(a);
				}
				
			}
			if( msg2.equals("16")) {
				if (t.getSource() == btn12)
				{
					btn12.setIcon(icon15);
					String a = "43";
					send_Message(a);
				}
				
			}
		}
	}
	
	class Myaction7 implements ActionListener{ //상대방선택
		
		@Override
		public void actionPerformed(ActionEvent t) {
			if(msg2.equals("1")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "14";
					send_Message(a);
				}
				
			}
			if( msg2.equals("2")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "24";
					send_Message(a);
				}
				
			}
			if(msg2.equals("3")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "34";
					send_Message(a);
				}
				
			}
			if( msg2.equals("4")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "44";
					send_Message(a);
				}
				
			}
			if(msg2.equals("5")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "14";
					send_Message(a);
				}
				
			}
			if( msg2.equals("6")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "24";
					send_Message(a);
				}
				
			}
			if(msg2.equals("7")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "34";
					send_Message(a);
				}
				
			}
			if( msg2.equals("8")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "44";
					send_Message(a);
				}
				
			}
			if(msg2.equals("9")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "14";
					send_Message(a);
				}
				
			}
			if( msg2.equals("10")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "24";
					send_Message(a);
				}
				
			}
			if(msg2.equals("11")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "34";
					send_Message(a);
				}
				
			}
			if( msg2.equals("12")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "44";
					send_Message(a);
				}
				
			}
			if(msg2.equals("13")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "14";
					send_Message(a);
				}
				
			}
			if( msg2.equals("14")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "24";
					send_Message(a);
				}
				
			}
			if(msg2.equals("15")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "34";
					send_Message(a);
				}
				
			}
			if( msg2.equals("16")) {
				if (t.getSource() == btn14)
				{
					btn14.setIcon(icon15);
					String a = "44";
					send_Message(a);
				}
				
			}
		}
	}
	class MyPanel extends JPanel{
        
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            g.drawImage(im,0,0,getWidth(),getHeight(),this);
        }
    }
	 
}
