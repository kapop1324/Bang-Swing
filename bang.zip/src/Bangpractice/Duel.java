package Bangpractice;

public class Duel {

	Duel(int p1, int p2, int p3, int p4){
		p1hp = p1;
		p2hp = p2;
		p3hp = p3;
		p4hp = p4;
		
		
	}
	int damage;
	int protection;
	int p1hp, p2hp, p3hp, p4hp;
	public int Card(int a) {
		//1은 뱅 2는 빗나감
		if(a == 1) {
			damage = 1;
			
			return damage;
		}
		else {
			
			protection = 1;
			
			return protection;
		}
	}
		
		public int Duel(int a, int b) {
		int attack, defense;
		attack = a;
		defense = b;
		int result;
		
		if(a == 1) {
			attack = 1;
			System.out.println("뱅으로 공격!");
		}else {
			attack = 0;
			System.out.println("아무것도 하지 않았습니다.!");
		}
		
			if(b==2) {
				defense = 1;
				System.out.println("빗나감!");
			}
			else {
				defense = 0;
				System.out.println("피하지 못했습니다.");
			}
		
		
		
		
		result = attack - defense;
		
		if(result > 0) {
			
			return result;
		
		}
		
		else {
			
			return 0;
			
		}
		
	}
		
	public int duelhp(String attackp ,String defensep, int result) {
		String attackplayer = attackp;
		String defenseplayer = defensep;
		int attackresult;
		int resultp = result;
		
		if(defenseplayer == "p1") {
			p1hp = p1hp - resultp;
			System.out.println(attackplayer+"님이 "+defenseplayer+"님 에게"+resultp+"의 데미지를 주었습니다.");
			System.out.println("현재 "+defenseplayer+"의 체력 : "+p1hp);
			
			return p1hp;
		}
		else if(defenseplayer == "p2") {
			p2hp = p2hp - resultp;
			System.out.println(attackplayer+"님이 "+defenseplayer+"님 에게"+resultp+"의 데미지를 주었습니다.");
			System.out.println("현재 "+defenseplayer+"의 체력 : "+p2hp);
			
			return p2hp;
		}
		else if(defenseplayer == "p3") {
			p3hp = p3hp - resultp;
			System.out.println(attackplayer+"님이 "+defenseplayer+"님 에게"+resultp+"의 데미지를 주었습니다.");
			System.out.println("현재 "+defenseplayer+"의 체력 : "+p3hp);
			
			return p3hp;
		}
		else {
			p4hp = p4hp - resultp;
			System.out.println(attackplayer+"님이 "+defenseplayer+"님 에게"+resultp+"의 데미지를 주었습니다.");
			System.out.println("현재 "+defenseplayer+"의 체력 : "+p4hp);
			
			return p4hp;
		}
		
		
	}
	
	public void resulthp() {
		System.out.println("");
		System.out.println("hp 현황");
		System.out.println("p1hp : "+p1hp);
		System.out.println("p2hp : "+p2hp);
		System.out.println("p3hp : "+p3hp);
		System.out.println("p4hp : "+p4hp);
		
	}
	
	String alive = "살아있음";
	
	public String p1dead() {
	
		if(p1hp == 0) {
			return "dead";
			
		}
		else {
			return "alive";
		}
		
		
	}
	
	public String p2dead() {
		
		
		if(p2hp == 0) {
			return "dead";
		}
		else {
			return "alive";
		}
		
		
	}
	
	public String p3dead() {
		
		
		if(p3hp == 0) {
			return "dead";
		}
		
		else {
			return "alive";
		}
		
	}
	
	public String p4dead() {
		
		if(p4hp == 0) {
			return "dead";
		}
		else {
			return "alive";
		}
		
		
	}
	
	
	
	public int gameresult(String p1c, String p2c, String p3c, String p4c) {
		
		String p1d = p1c;
		String p2d = p2c;
		String p3d = p3c;
		String p4d = p4c;
		
		
		if(p1d == "보안관" || p2c == "보안관" || p3c == "보안관" || p4c == "보안관") {
			System.out.println("무법자가 승리하였습니다");
			return 1;
		}
		else if((p1d=="무법자"&&p2d=="배신자")||(p1d=="무법자"&&p3d=="배신자")||(p1d=="무법자"&&p4d=="배신자")||
				(p2d=="무법자"&&p1d=="배신자")||(p2d=="무법자"&&p3d=="배신자")||(p2d=="무법자"&&p4d=="배신자")||
				(p3d=="무법자"&&p1d=="배신자")||(p3d=="무법자"&&p2d=="배신자")||(p3d=="무법자"&&p4d=="배신자")||
				(p4d=="무법자"&&p1d=="배신자")||(p4d=="무법자"&&p2d=="배신자")||(p4d=="무법자"&&p3d=="배신자")) {
			
			return 1;
		}
		else if((p1d != "배신자" && p1d != "alive") &&(p2d != "배신자" && p2d != "alive")&&(p3d != "배신자" && p3d != "alive")&&(p4d != "배신자" && p4d != "alive")) {
			return 1;
		}
		else {
			return 0;
		}
		
	}
	
}
