package Bangpractice;

import java.util.Scanner;

public class Turn {
	int p1tn, p2tn, p3tn, p4tn;
	int asd;
	int input;
	Turn(int a, int b, int c, int d){
		
		p1tn = a;
		p2tn = b;
		p3tn = c;
		p4tn = d;	
		
	}
	
	public void Turn() {
		
		Scanner sc = new Scanner(System.in);
		
		if(p1tn == 1) {
			System.out.println("이번 게임 순서 1번 : p1 2번 : p2 3번 : p3 4번 : p4 ");
			System.out.println("");
			
		}
		else if(p2tn == 1){
			System.out.println("이번 게임 순서 1번 : p2 2번 : p3 3번 : p4 4번 : p1 ");
			System.out.println("");
		}
		else if(p3tn == 1){
			System.out.println("이번 게임 순서 1번 : p3 2번 : p4 3번 : p1 4번 : p2 ");
			System.out.println("");
		}
		else if(p4tn == 1){
			System.out.println("이번 게임 순서 1번 : p4 2번 : p1 3번 : p2 4번 : p3 ");
			System.out.println("");
		}
		
	}
	
	
	

}
